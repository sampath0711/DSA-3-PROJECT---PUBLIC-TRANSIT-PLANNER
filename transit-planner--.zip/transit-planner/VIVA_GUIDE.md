# Presentation guide (read this the night before)

## 30-second pitch
"Our project is a Public Transit Planner. A city has a fixed number of buses and a fixed daily budget. Our Java program
decides which bus lines to run, how many buses each line gets and when they leave, then measures the result:
coverage, waiting time, travel time, cost. Passengers use a website to find which bus to take; the transit agency
uses an admin side to set the fleet and budget and publish the plan. Every algorithm is written by hand, with no java.util."

## Demo script (5 minutes)
1. Start it:  `javac -d out src/transit/*.java`  then  `java -cp out transit.Server`  and open http://localhost:8080
2. **Passenger > Plan a trip:** tap "Try an example trip". Show arrival time, next buses, "Show stops". Press "Leave 15 min later".
3. **Passenger > Departures:** type a stop (try a typo, "ameerpt") to show the departure board (edit distance repairs the typo).
4. **Passenger > Try Aziz Nagar to Uppal:** the app says no bus connects them. Explain this is a real coverage gap the admin can fix.
5. **Admin (PIN 1234):** move the "Number of buses" slider; the sentence under "What this plan means" and the colour cards change.
6. Click **"Find the best fleet size"**. It tests 30 to 70 buses and recommends one. Click "Use ... buses".
7. Click **Publish to passengers**, go back to Passenger: "Today's service" now shows the new fleet.
8. Terminal: `java -cp out transit.Main selftest` shows 7,470 checks passed. `java -cp out transit.Main demo` shows all modules.

## Which algorithm answers which question
| Question | Answer |
|---|---|
| How do you fix typos in stop names? | Damerau-Levenshtein edit distance (DP, Module 3); duplicates found with a hash table |
| How is the fastest path found? | Dijkstra with a binary heap |
| How are bus lines chosen? | Greedy budgeted coverage. The exact problem is NP-hard (Module 5); greedy is within 63% (1 - 1/e) of the best possible |
| How are buses split between lines? | Dynamic programming: dp[line][buses] = least waiting time (Module 3) |
| How are riders placed without overfilling buses? | Min-cost max-flow; Edmonds-Karp and Dinic cross-check the max flow with a min cut (Module 4) |
| How do you know the waiting time is right? | Monte Carlo simulation of 300,000 riders (Module 6); simulated 7.57 min vs analytic 7.57 min |
| Where is randomness used? | Miller-Rabin primes for hashing, randomised quicksort, reservoir sampling (Module 6) |
| Where are string algorithms used? | Aho-Corasick finds stop names in a sentence, suffix array + LCP for substring search, KMP/Z/Rabin-Karp (Module 2) |
| Is it parallel? | Prefix-sum and reduce on threads (Module 6) |

## Honest answers to hard questions
* **Is the data real?** No. It is synthetic: real Hyderabad locality names, approximate coordinates, demand from a gravity model. The code reads CSV files, so real data can be dropped in.
* **Is the admin PIN secure?** It is checked by the Java server, but this is a demo: plain HTTP, one shared token, nothing saved to disk.
* **What are the limits?** Riders who change buses count in travel time but not in the seat-capacity check; each line is a fixed two-way route; no live traffic.
* **Why is Aziz Nagar unserved?** The budget/fleet is spent on busier corridors first. With a larger fleet the planner covers more.
* **What would you add next?** Real GTFS data, a database for published plans, live bus positions, fares.

## Team tip
Each of you should be able to explain at least one algorithm in your own words. Lecturers often ask each person something different.
