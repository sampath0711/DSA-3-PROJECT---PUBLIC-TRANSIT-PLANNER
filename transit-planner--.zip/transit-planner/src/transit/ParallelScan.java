package transit;

/** Module 6: parallel prefix-sum (chunked 3-phase scan on threads) and a sequential Blelloch up/down-sweep. */
public final class ParallelScan {
    private ParallelScan() {}

    /** Inclusive scan. Work O(n), span O(n/T + T) with T threads. */
    public static long[] inclusive(final long[] a, int threads) {
        final int n = a.length; final long[] out = new long[n];
        if (n == 0) return out;
        final int T = Math.max(1, Math.min(threads, n));
        final int[] lo = new int[T + 1];
        for (int t = 0; t <= T; t++) lo[t] = (int) ((long) n * t / T);
        final long[] sums = new long[T];
        run(T, id -> { long s = 0; for (int i = lo[id]; i < lo[id + 1]; i++) { s += a[i]; out[i] = s; } sums[id] = s; });
        final long[] off = new long[T];
        for (int t = 1; t < T; t++) off[t] = off[t - 1] + sums[t - 1];
        run(T, id -> { for (int i = lo[id]; i < lo[id + 1]; i++) out[i] += off[id]; });
        return out;
    }
    /** Parallel reduce (sum). */
    public static long sum(final long[] a, int threads) {
        final int n = a.length; if (n == 0) return 0;
        final int T = Math.max(1, Math.min(threads, n));
        final long[] part = new long[T];
        run(T, id -> { long s = 0; int from = (int) ((long) n * id / T), to = (int) ((long) n * (id + 1) / T); for (int i = from; i < to; i++) s += a[i]; part[id] = s; });
        long s = 0; for (long v : part) s += v;
        return s;
    }
    /** Blelloch exclusive scan; length must be a power of two. Each level's loop iterations are independent. */
    public static long[] blellochExclusive(long[] in) {
        int n = in.length; long[] a = new long[n]; System.arraycopy(in, 0, a, 0, n);
        for (int d = 1; d < n; d <<= 1)                       // up-sweep (reduce)
            for (int i = 2 * d - 1; i < n; i += 2 * d) a[i] += a[i - d];
        a[n - 1] = 0;
        for (int d = n >> 1; d >= 1; d >>= 1)                 // down-sweep
            for (int i = 2 * d - 1; i < n; i += 2 * d) { long t = a[i - d]; a[i - d] = a[i]; a[i] += t; }
        return a;
    }

    private interface Task { void run(int id); }
    private static void run(int T, final Task task) {
        Thread[] th = new Thread[T];
        for (int t = 0; t < T; t++) { final int id = t; th[t] = new Thread(() -> task.run(id)); th[t].start(); }
        for (int t = 0; t < T; t++) { try { th[t].join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }
    }
}
