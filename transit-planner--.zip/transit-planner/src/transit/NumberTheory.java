package transit;

/** Miller-Rabin primality (randomised/deterministic-base) for n < 2^62. */
public final class NumberTheory {
    private NumberTheory() {}
    private static final long[] BASES = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37};

    public static long mulmod(long a, long b, long m) {      // m < 2^62, no overflow
        long r = 0; a %= m; b %= m;
        while (b > 0) {
            if ((b & 1) == 1) { r += a; if (r >= m) r -= m; }
            a <<= 1; if (a >= m) a -= m;
            b >>= 1;
        }
        return r;
    }
    public static long powmod(long b, long e, long m) {
        long r = 1 % m; b %= m;
        while (e > 0) { if ((e & 1) == 1) r = mulmod(r, b, m); b = mulmod(b, b, m); e >>= 1; }
        return r;
    }
    public static boolean isPrime(long n) {
        if (n < 2) return false;
        for (long p : BASES) if (n % p == 0) return n == p;
        long d = n - 1; int s = 0;
        while ((d & 1) == 0) { d >>= 1; s++; }
        for (long a : BASES) {
            long x = powmod(a, d, n);
            if (x == 1 || x == n - 1) continue;
            boolean composite = true;
            for (int r = 1; r < s; r++) { x = mulmod(x, x, n); if (x == n - 1) { composite = false; break; } }
            if (composite) return false;
        }
        return true;
    }
    /** Plain Fermat test - fooled by Carmichael numbers such as 561. */
    public static boolean fermatPasses(long n, long a) { return powmod(a, n - 1, n) == 1; }

    public static long randomPrime(int bits, Rng r) {
        while (true) {
            long c = (1L << (bits - 1)) | (r.nextLong() & ((1L << (bits - 1)) - 1)) | 1L;
            if (isPrime(c)) return c;
        }
    }
}
