package transit;

/** Growable int array (replacement for ArrayList<Integer>). */
public final class IntList {
    private int[] a = new int[8];
    private int n;
    public void add(int v) {
        if (n == a.length) { int[] b = new int[n * 2]; System.arraycopy(a, 0, b, 0, n); a = b; }
        a[n++] = v;
    }
    public int get(int i) { return a[i]; }
    public void set(int i, int v) { a[i] = v; }
    public int size() { return n; }
    public void clear() { n = 0; }
    public boolean contains(int v) { for (int i = 0; i < n; i++) if (a[i] == v) return true; return false; }
    public int[] toArray() { int[] b = new int[n]; System.arraycopy(a, 0, b, 0, n); return b; }
    public void reverse() { for (int i = 0, j = n - 1; i < j; i++, j--) { int t = a[i]; a[i] = a[j]; a[j] = t; } }
}
