package transit;

import java.io.FileWriter;
import java.io.IOException;

/** Builds the self-contained interactive HTML report (inline SVG + a little JS for scenario switching). */
public final class ReportWriter {
    private ReportWriter() {}
    private static final String[] COL = {"#e6550d", "#3182bd", "#31a354", "#756bb1", "#d6616b", "#8c6d31", "#17becf", "#e7ba52", "#636363", "#a1d99b"};

    private static String esc(String s) { return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }

    public static String kpis(Planner.Plan p) {
        StringBuilder b = new StringBuilder("<div class=kpis>");
        kpi(b, "Stop coverage", Fmt.pct(p.stopCoverage)); kpi(b, "Demand served directly", Fmt.pct(p.directShare));
        kpi(b, "Demand reachable", Fmt.pct(p.reachShare)); kpi(b, "Avg waiting time", Fmt.f(p.avgWait, 1) + " min");
        kpi(b, "Avg door-to-door time", Fmt.f(p.avgTravel, 1) + " min"); kpi(b, "Fleet utilisation", Fmt.pct(p.fleetUtil));
        kpi(b, "Peak buses in use", p.peakFleet + " / " + p.p.fleet); kpi(b, "Daily operating cost", Fmt.money(p.dailyCost));
        kpi(b, "Peak-hour unmet demand", Fmt.pct(p.unmetPeakShare));
        return b.append("</div>").toString();
    }
    private static void kpi(StringBuilder b, String k, String v) { b.append("<div class=kpi><span>").append(k).append("</span><b>").append(v).append("</b></div>"); }

    public static String mapSvg(Planner.Plan p) {
        TransitData d = p.d; double minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
        for (int i = 0; i < d.n; i++) { minX = Math.min(minX, d.x[i]); maxX = Math.max(maxX, d.x[i]); minY = Math.min(minY, d.y[i]); maxY = Math.max(maxY, d.y[i]); }
        double W = 820, H = 540, pad = 50, sx = (W - 2 * pad) / (maxX - minX), sy = (H - 2 * pad) / (maxY - minY), s = Math.min(sx, sy);
        StringBuilder b = new StringBuilder("<svg viewBox='0 0 " + (int) W + " " + (int) H + "' class=map>");
        for (int i = 0; i < d.m; i++) b.append(line(d, d.eu[i], d.ev[i], minX, maxY, s, pad, "var(--road)", 1.2, 1));
        for (int r = 0; r < p.routes.length; r++) {
            Planner.Route ro = p.routes[r]; StringBuilder pts = new StringBuilder();
            for (int st : ro.stops) pts.append(Fmt.f(pad + (d.x[st] - minX) * s, 1)).append(',').append(Fmt.f(pad + (maxY - d.y[st]) * s, 1)).append(' ');
            b.append("<polyline points='").append(pts).append("' fill=none stroke='").append(COL[r % COL.length]).append("' stroke-width=4 stroke-linejoin=round stroke-linecap=round opacity=.8><title>Route ").append(r + 1).append("</title></polyline>");
        }
        boolean[] served = new boolean[d.n];
        for (Planner.Route ro : p.routes) for (int st : ro.stops) served[st] = true;
        for (int i = 0; i < d.n; i++) {
            double cx = pad + (d.x[i] - minX) * s, cy = pad + (maxY - d.y[i]) * s;
            b.append("<circle cx=").append(Fmt.f(cx, 1)).append(" cy=").append(Fmt.f(cy, 1)).append(" r=").append(Fmt.f(3 + d.weight[i] * 0.5, 1))
             .append(served[i] ? " fill='var(--stop)'" : " fill='var(--bg)' stroke='var(--muted)'").append("/><text x=").append(Fmt.f(cx + 7, 1)).append(" y=").append(Fmt.f(cy - 6, 1)).append(">").append(esc(d.name[i])).append("</text>");
        }
        return b.append("</svg>").toString();
    }
    private static String line(TransitData d, int u, int v, double minX, double maxY, double s, double pad, String col, double w, double op) {
        return "<line x1=" + Fmt.f(pad + (d.x[u] - minX) * s, 1) + " y1=" + Fmt.f(pad + (maxY - d.y[u]) * s, 1) + " x2=" + Fmt.f(pad + (d.x[v] - minX) * s, 1) + " y2=" + Fmt.f(pad + (maxY - d.y[v]) * s, 1) + " stroke='" + col + "' stroke-width=" + w + " opacity=" + op + " />";
    }

    public static String routeTable(Planner.Plan p) {
        TransitData d = p.d; StringBuilder b = new StringBuilder("<div class=scroll><table><tr><th>#<th>Route (terminals)<th>Stops<th>One-way<th>Km<th>Buses<th>Peak freq/h<th>Avg wait<th>Daily demand<th>Daily cost<th>Peak load/cap<th>Note</tr>");
        for (int r = 0; r < p.routes.length; r++) {
            Planner.Route ro = p.routes[r]; int pf = 0; for (int h = 0; h < Planner.NH; h++) pf = Math.max(pf, ro.freq[h]);
            b.append("<tr><td><i style='background:").append(COL[r % COL.length]).append("'></i>").append(r + 1).append("<td>").append(esc(d.name[ro.stops[0]])).append(" &harr; ").append(esc(d.name[ro.stops[ro.stops.length - 1]]))
             .append("<td>").append(ro.stops.length).append("<td>").append(Fmt.f(ro.oneWayMin, 0)).append(" min<td>").append(Fmt.f(ro.oneWayKm, 1)).append("<td>").append(ro.buses).append("<td>").append(pf)
             .append("<td>").append(Fmt.f(ro.avgWait, 1)).append(" min<td>").append(Fmt.money(ro.dailyDemand).substring(3)).append("<td>").append(Fmt.money(ro.dailyCost)).append("<td>").append(Fmt.f(ro.peakLoad, 0)).append(" / ").append(Fmt.f(ro.peakCap, 0))
             .append("<td>").append(ro.bottleneck ? "<span class=warn>min-cut bottleneck</span>" : "").append("</tr>");
        }
        return b.append("</table></div>").toString();
    }

    public static String stopList(Planner.Plan p) {
        StringBuilder b = new StringBuilder("<ul class=stops>");
        for (int r = 0; r < p.routes.length; r++) {
            b.append("<li><i style='background:").append(COL[r % COL.length]).append("'></i><b>Route ").append(r + 1).append(":</b> ");
            for (int i = 0; i < p.routes[r].stops.length; i++) { if (i > 0) b.append(" &rarr; "); b.append(esc(p.d.name[p.routes[r].stops[i]])); }
            b.append("</li>");
        }
        return b.append("</ul>").toString();
    }

    /** Departures per hour per route as a heat table, plus the first departures of the morning peak. */
    public static String timetable(Planner.Plan p) {
        StringBuilder b = new StringBuilder("<div class=scroll><table class=tt><tr><th>Route");
        for (int h = 0; h < Planner.NH; h++) b.append("<th>").append(TransitData.H0 + h);
        b.append("<th>Fleet</tr>");
        int mx = 1; for (Planner.Route ro : p.routes) for (int f : ro.freq) mx = Math.max(mx, f);
        for (int r = 0; r < p.routes.length; r++) {
            b.append("<tr><td>").append(r + 1);
            for (int h = 0; h < Planner.NH; h++) b.append("<td style='background:rgba(49,130,189,").append(Fmt.f(0.12 + 0.75 * p.routes[r].freq[h] / mx, 2)).append(")'>").append(p.routes[r].freq[h]);
            b.append("<td>").append(p.routes[r].buses).append("</tr>");
        }
        b.append("<tr><td>Buses<br>in use");
        for (int h = 0; h < Planner.NH; h++) b.append("<td>").append(p.hourFleet[h]);
        b.append("<td>").append(p.p.fleet).append("</tr></table></div><p class=note>Cells = departures per hour (each direction). Example, Route 1 at 08:00: ");
        Planner.Route r0 = p.routes[0]; int f8 = r0.freq[3];
        for (int i = 0; i < f8; i++) { int mm = (int) Math.round(i * 60.0 / f8); b.append("08:").append(mm < 10 ? "0" : "").append(mm).append(i < f8 - 1 ? ", " : ""); }
        return b.append(".</p>").toString();
    }

    public static String bars(String title, String[] labels, double[] vals, String unit, int dec) {
        double mx = 0; for (double v : vals) mx = Math.max(mx, v);
        int w = 90 * labels.length + 60; StringBuilder b = new StringBuilder("<svg viewBox='0 0 " + w + " 220' class=bars><text x=10 y=16 class=ct>" + esc(title) + "</text>");
        for (int i = 0; i < vals.length; i++) {
            double h = mx > 0 ? 140 * vals[i] / mx : 0, x = 40 + i * 90;
            b.append("<rect x=").append(x).append(" y=").append(Fmt.f(180 - h, 1)).append(" width=60 height=").append(Fmt.f(h, 1)).append(" rx=3 fill='var(--bar)'/><text x=").append(x + 30).append(" y=").append(Fmt.f(174 - h, 1)).append(" text-anchor=middle>").append(Fmt.f(vals[i], dec)).append(unit)
             .append("</text><text x=").append(x + 30).append(" y=198 text-anchor=middle>").append(esc(labels[i])).append("</text>");
        }
        return b.append("</svg>").toString();
    }

    public static String scenarioTable(String[] names, Planner.Plan[] ps) {
        StringBuilder b = new StringBuilder("<div class=scroll><table><tr><th>Scenario<th>Fleet<th>Budget/day<th>Routes<th>Stops covered<th>Direct demand<th>Reachable<th>Avg wait<th>Avg trip<th>Fleet util.<th>Peak unmet<th>Daily cost</tr>");
        for (int i = 0; i < ps.length; i++) {
            Planner.Plan p = ps[i];
            b.append("<tr><td>").append(esc(names[i])).append("<td>").append(p.p.fleet).append("<td>").append(p.p.dailyBudget > 1e11 ? "none" : Fmt.money(p.p.dailyBudget)).append("<td>").append(p.routes.length)
             .append("<td>").append(Fmt.pct(p.stopCoverage)).append("<td>").append(Fmt.pct(p.directShare)).append("<td>").append(Fmt.pct(p.reachShare)).append("<td>").append(Fmt.f(p.avgWait, 1)).append(" min<td>").append(Fmt.f(p.avgTravel, 1)).append(" min<td>")
             .append(Fmt.pct(p.fleetUtil)).append("<td>").append(Fmt.pct(p.unmetPeakShare)).append("<td>").append(Fmt.money(p.dailyCost)).append("</tr>");
        }
        return b.append("</table></div>").toString();
    }

    public static void write(String path, String title, String[] sectionTitles, String[] sectionHtml) throws IOException {
        StringBuilder b = new StringBuilder();
        b.append("<!doctype html><html lang=en><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>").append(esc(title)).append("</title><style>")
         .append(":root{--bg:#fff;--fg:#1b1f24;--muted:#6b7280;--card:#f4f6f8;--line:#d9dee4;--road:#c3cad3;--stop:#1b1f24;--bar:#3182bd;--warn:#b45309}")
         .append("@media(prefers-color-scheme:dark){:root{--bg:#14171c;--fg:#e8ebef;--muted:#9aa3ae;--card:#1d222a;--line:#313843;--road:#3c4552;--stop:#e8ebef;--bar:#6baed6;--warn:#fbbf24}}")
         .append("body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.5 system-ui,sans-serif}main{max-width:1100px;margin:auto;padding:24px 16px 60px}h1{margin:.2em 0}h2{margin-top:2em;border-bottom:1px solid var(--line);padding-bottom:.2em}")
         .append(".kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px}.kpi{background:var(--card);border-radius:10px;padding:10px 12px}.kpi span{display:block;color:var(--muted);font-size:12px}.kpi b{font-size:20px}")
         .append(".scroll{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:13px}th,td{border-bottom:1px solid var(--line);padding:6px 8px;text-align:left;white-space:nowrap}th{color:var(--muted);font-weight:600}.tt td{text-align:center;padding:4px 6px}")
         .append("i{display:inline-block;width:12px;height:12px;border-radius:3px;margin-right:6px;vertical-align:-1px}.map{width:100%;height:auto;background:var(--card);border-radius:12px}.map text{font-size:10px;fill:var(--fg)}")
         .append(".bars{width:100%;max-width:560px;height:auto}.bars text{font-size:11px;fill:var(--fg)}.bars .ct{font-weight:600}.warn{color:var(--warn)}.note,pre{color:var(--muted);font-size:13px}pre{background:var(--card);padding:12px;border-radius:10px;overflow-x:auto}")
         .append(".stops{list-style:none;padding:0;font-size:13px}.stops li{margin:4px 0}.tabs button{background:var(--card);color:var(--fg);border:1px solid var(--line);border-radius:8px;padding:6px 12px;margin:0 6px 8px 0;cursor:pointer}.tabs button.on{background:var(--bar);color:#fff;border-color:var(--bar)}")
         .append("</style></head><body><main><h1>").append(esc(title)).append("</h1>");
        for (int i = 0; i < sectionTitles.length; i++) b.append("<h2>").append(esc(sectionTitles[i])).append("</h2>").append(sectionHtml[i]);
        b.append("</main></body></html>");
        FileWriter w = new FileWriter(path); w.write(b.toString()); w.close();
    }
    public static String pre(String s) { return "<pre>" + esc(s) + "</pre>"; }
    public static String tabs(String[] names, String[] panes) {
        StringBuilder b = new StringBuilder("<div class=tabs>");
        for (int i = 0; i < names.length; i++) b.append("<button class='").append(i == 0 ? "on" : "").append("' onclick='sw(").append(i).append(",this)'>").append(esc(names[i])).append("</button>");
        b.append("</div>");
        for (int i = 0; i < panes.length; i++) b.append("<div class=pane style='display:").append(i == 0 ? "block" : "none").append("'>").append(panes[i]).append("</div>");
        b.append("<script>function sw(i,btn){var p=document.querySelectorAll('.pane'),t=btn.parentNode.children;for(var k=0;k<p.length;k++){p[k].style.display=k==i?'block':'none';t[k].className=k==i?'on':''}}</script>");
        return b.toString();
    }
}
