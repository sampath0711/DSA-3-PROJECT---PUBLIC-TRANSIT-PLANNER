package transit;

/** Module 3: sequence alignment, applied to route stop-sequences (overlap detection). */
public final class Alignment {
    private Alignment() {}
    /** Needleman-Wunsch global alignment score. */
    public static int global(int[] a, int[] b, int match, int mismatch, int gap) {
        int n = a.length, m = b.length;
        int[][] s = new int[n + 1][m + 1];
        for (int i = 1; i <= n; i++) s[i][0] = i * gap;
        for (int j = 1; j <= m; j++) s[0][j] = j * gap;
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= m; j++) {
                int diag = s[i - 1][j - 1] + (a[i - 1] == b[j - 1] ? match : mismatch);
                s[i][j] = Math.max(diag, Math.max(s[i - 1][j] + gap, s[i][j - 1] + gap));
            }
        return s[n][m];
    }
    /** Smith-Waterman local alignment score (best shared corridor of two routes). */
    public static int local(int[] a, int[] b, int match, int mismatch, int gap) {
        int n = a.length, m = b.length, best = 0;
        int[][] s = new int[n + 1][m + 1];
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= m; j++) {
                int diag = s[i - 1][j - 1] + (a[i - 1] == b[j - 1] ? match : mismatch);
                s[i][j] = Math.max(0, Math.max(diag, Math.max(s[i - 1][j] + gap, s[i][j - 1] + gap)));
                if (s[i][j] > best) best = s[i][j];
            }
        return best;
    }
}
