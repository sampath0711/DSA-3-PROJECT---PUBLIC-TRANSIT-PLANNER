package transit;

/** Randomised 3-way quicksort (Las Vegas: always correct, expected O(n log n)). */
public final class Sorting {
    private static final Rng R = new Rng(12345);
    private Sorting() {}

    /** Sorts idx so that key[idx[0]] <= key[idx[1]] <= ... (ascending). */
    public static void sortIdx(int[] idx, long[] key) { qs(idx, key, 0, idx.length - 1); }

    private static void qs(int[] idx, long[] key, int lo, int hi) {
        while (lo < hi) {
            long p = key[idx[lo + R.nextInt(hi - lo + 1)]];
            int lt = lo, i = lo, gt = hi;
            while (i <= gt) {
                long k = key[idx[i]];
                if (k < p) swap(idx, lt++, i++);
                else if (k > p) swap(idx, i, gt--);
                else i++;
            }
            if (lt - lo < hi - gt) { qs(idx, key, lo, lt - 1); lo = gt + 1; }
            else { qs(idx, key, gt + 1, hi); hi = lt - 1; }
        }
    }
    private static void swap(int[] a, int i, int j) { int t = a[i]; a[i] = a[j]; a[j] = t; }

    public static void sort(int[] a) {
        long[] key = new long[a.length]; int[] idx = new int[a.length];
        for (int i = 0; i < a.length; i++) { key[i] = a[i]; idx[i] = i; }
        sortIdx(idx, key);
        int[] out = new int[a.length];
        for (int i = 0; i < a.length; i++) out[i] = a[idx[i]];
        System.arraycopy(out, 0, a, 0, a.length);
    }
}
