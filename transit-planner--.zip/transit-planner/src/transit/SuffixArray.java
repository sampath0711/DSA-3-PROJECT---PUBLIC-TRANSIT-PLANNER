package transit;

/** Module 2: suffix array (prefix doubling, O(n log^2 n)) + Kasai LCP + binary-search pattern lookup. */
public final class SuffixArray {
    public final String s; public final int[] sa, rank, lcp;

    public SuffixArray(String s) {
        this.s = s; int n = s.length();
        sa = new int[n]; rank = new int[n]; lcp = new int[n];
        build(); kasai();
    }
    private void build() {
        int n = s.length(); if (n == 0) return;
        int[] rk = new int[n], tmp = new int[n]; long[] key = new long[n];
        for (int i = 0; i < n; i++) { sa[i] = i; rk[i] = s.charAt(i); }
        long B = 65536L + n + 2;
        for (int k = 1; ; k <<= 1) {
            for (int i = 0; i < n; i++) key[i] = rk[i] * B + (i + k < n ? rk[i + k] + 1 : 0);
            Sorting.sortIdx(sa, key);
            tmp[sa[0]] = 0;
            for (int i = 1; i < n; i++) tmp[sa[i]] = tmp[sa[i - 1]] + (key[sa[i]] != key[sa[i - 1]] ? 1 : 0);
            System.arraycopy(tmp, 0, rk, 0, n);
            if (rk[sa[n - 1]] == n - 1 || k >= n) break;
        }
        System.arraycopy(rk, 0, rank, 0, n);
    }
    /** Kasai's algorithm: lcp[r] = LCP(suffix sa[r-1], suffix sa[r]) in O(n). */
    private void kasai() {
        int n = s.length(), h = 0;
        for (int i = 0; i < n; i++) {
            if (rank[i] > 0) {
                int j = sa[rank[i] - 1];
                while (i + h < n && j + h < n && s.charAt(i + h) == s.charAt(j + h)) h++;
                lcp[rank[i]] = h;
                if (h > 0) h--;
            } else h = 0;
        }
    }
    private int cmp(int pos, String p) {   // 0 => p is a prefix of the suffix
        for (int i = 0; i < p.length(); i++) {
            if (pos + i >= s.length()) return -1;
            char a = s.charAt(pos + i), b = p.charAt(i);
            if (a != b) return a < b ? -1 : 1;
        }
        return 0;
    }
    private int bound(String p, boolean upper) {
        int lo = 0, hi = sa.length;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1, c = cmp(sa[mid], p);
            if (upper ? c <= 0 : c < 0) lo = mid + 1; else hi = mid;
        }
        return lo;
    }
    /** Range [lo,hi) of suffix-array rows whose suffix starts with p - O(m log n). */
    public int[] range(String p) { return new int[]{bound(p, false), bound(p, true)}; }
    /** Longest substring occurring at least twice (max LCP value). */
    public String longestRepeated() {
        int best = 0, at = 0;
        for (int r = 1; r < lcp.length; r++) if (lcp[r] > best) { best = lcp[r]; at = sa[r]; }
        return s.substring(at, at + best);
    }
}
