package transit;

/** Weighted directed graph in forward-star (arrays) form + Dijkstra. */
public final class Graph {
    public static final double INF = 1e18;
    public final int n; private final int[] head; private int[] nxt = new int[16], to = new int[16];
    private double[] w = new double[16]; private int m;

    public Graph(int n) { this.n = n; head = new int[n]; for (int i = 0; i < n; i++) head[i] = -1; }
    public void addEdge(int u, int v, double wt) {
        if (m == to.length) {
            int[] a = new int[m * 2], b = new int[m * 2]; double[] c = new double[m * 2];
            System.arraycopy(nxt, 0, a, 0, m); System.arraycopy(to, 0, b, 0, m); System.arraycopy(w, 0, c, 0, m);
            nxt = a; to = b; w = c;
        }
        to[m] = v; w[m] = wt; nxt[m] = head[u]; head[u] = m++;
    }
    public void addUndirected(int u, int v, double wt) { addEdge(u, v, wt); addEdge(v, u, wt); }
    public int first(int u) { return head[u]; }
    public int next(int e) { return nxt[e]; }
    public int to(int e) { return to[e]; }
    public double w(int e) { return w[e]; }

    public static final class SP { public double[] dist; public int[] parent; }

    public SP dijkstra(int src) {
        SP r = new SP(); r.dist = new double[n]; r.parent = new int[n];
        for (int i = 0; i < n; i++) { r.dist[i] = INF; r.parent[i] = -1; }
        MinHeap h = new MinHeap(); r.dist[src] = 0; h.push(0, src);
        while (!h.isEmpty()) {
            double d = h.peekPrio(); int u = h.pop();
            if (d > r.dist[u]) continue;
            for (int e = head[u]; e != -1; e = nxt[e]) {
                double nd = d + w[e];
                if (nd < r.dist[to[e]]) { r.dist[to[e]] = nd; r.parent[to[e]] = u; h.push(nd, to[e]); }
            }
        }
        return r;
    }
    /** Node sequence src..target, or null if unreachable. */
    public static int[] path(SP sp, int target) {
        if (sp.dist[target] >= INF) return null;
        IntList l = new IntList();
        for (int v = target; v != -1; v = sp.parent[v]) l.add(v);
        l.reverse();
        return l.toArray();
    }
    public boolean connected() {
        boolean[] seen = new boolean[n]; int[] q = new int[n]; int qh = 0, qt = 0, cnt = 1;
        q[qt++] = 0; seen[0] = true;
        while (qh < qt) {
            int u = q[qh++];
            for (int e = head[u]; e != -1; e = nxt[e]) if (!seen[to[e]]) { seen[to[e]] = true; cnt++; q[qt++] = to[e]; }
        }
        return cnt == n;
    }
}
