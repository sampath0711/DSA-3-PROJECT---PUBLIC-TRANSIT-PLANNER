package transit;

/** Hand-built xorshift64 pseudo-random generator (no java.util.Random). */
public final class Rng {
    private long s;
    public Rng(long seed) {
        s = seed == 0 ? 0x9E3779B97F4A7C15L : seed;
        for (int i = 0; i < 8; i++) nextLong();
    }
    public long nextLong() { s ^= s << 13; s ^= s >>> 7; s ^= s << 17; return s; }
    public int nextInt(int bound) { return (int) ((nextLong() >>> 1) % bound); }
    public double nextDouble() { return (nextLong() >>> 11) * (1.0 / (1L << 53)); }
}
