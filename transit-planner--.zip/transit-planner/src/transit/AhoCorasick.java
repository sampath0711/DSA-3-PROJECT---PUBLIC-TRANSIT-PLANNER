package transit;

/** Module 2: multi-pattern matching. Trie + failure links + dictionary links (ASCII patterns). */
public final class AhoCorasick {
    private final int[][] go; private final int[] fail, link, pid;
    private int nodes = 1;

    public AhoCorasick(String[] pats) {
        int total = 1;
        for (String p : pats) total += p.length();
        go = new int[total][128]; fail = new int[total]; link = new int[total]; pid = new int[total];
        for (int i = 0; i < total; i++) { pid[i] = -1; link[i] = -1; for (int c = 0; c < 128; c++) go[i][c] = -1; }
        for (int i = 0; i < pats.length; i++) {
            int u = 0;
            for (int j = 0; j < pats[i].length(); j++) {
                int c = pats[i].charAt(j) & 127;
                if (go[u][c] == -1) go[u][c] = nodes++;
                u = go[u][c];
            }
            pid[u] = i;
        }
        int[] q = new int[nodes]; int qh = 0, qt = 0;
        for (int c = 0; c < 128; c++) {
            if (go[0][c] == -1) go[0][c] = 0; else { fail[go[0][c]] = 0; q[qt++] = go[0][c]; }
        }
        while (qh < qt) {
            int u = q[qh++];
            for (int c = 0; c < 128; c++) {
                int v = go[u][c];
                if (v == -1) go[u][c] = go[fail[u]][c];
                else {
                    fail[v] = go[fail[u]][c];
                    link[v] = pid[fail[v]] >= 0 ? fail[v] : link[fail[v]];
                    q[qt++] = v;
                }
            }
        }
    }
    /** Returns flattened pairs [patternIndex, endIndex, ...]. */
    public IntList search(String text) {
        IntList out = new IntList(); int s = 0;
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch >= 128) { s = 0; continue; }
            s = go[s][ch];
            for (int v = pid[s] >= 0 ? s : link[s]; v != -1; v = link[v]) { out.add(pid[v]); out.add(i); }
        }
        return out;
    }
}
