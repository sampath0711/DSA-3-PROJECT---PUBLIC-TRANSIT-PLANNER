package transit;

import java.io.File;

/**
 * Public Transit Planner - DSA-3 project (25CS2103E).
 * Commands:  demo | selftest | search <text> | fuzzy <name> | route <A> <B> | plan [fleet] [dailyBudget] | tsp
 * Data folder: -Ddata=DIR (default "data"); report folder: -Dout=DIR (default "output").
 * Engine rule inherited from DSA-1/2: nothing from java.util is used anywhere in this package.
 */
public final class Main {
    private static TransitData d;
    private static String[] keys; private static StrMap map;

    public static void main(String[] args) throws Exception {
        String dataDir = System.getProperty("data", "data"), outDir = System.getProperty("out", "output");
        String cmd = args.length > 0 ? args[0] : "demo";
        if (cmd.equals("selftest")) { System.exit(SelfTest.run() ? 0 : 1); }
        d = DataCleaner.load(dataDir);
        keys = new String[d.n]; map = new StrMap(new Rng(5));
        for (int i = 0; i < d.n; i++) { keys[i] = DataCleaner.norm(d.name[i]); map.put(keys[i], i); }
        if (cmd.equals("search")) search(join(args, 1));
        else if (cmd.equals("fuzzy")) fuzzy(join(args, 1));
        else if (cmd.equals("route")) route(args.length > 1 ? args[1] : "", args.length > 2 ? args[2] : "");
        else if (cmd.equals("plan")) {
            Planner.Params p = new Planner.Params();
            if (args.length > 1) p.fleet = Integer.parseInt(args[1]);
            if (args.length > 2) p.dailyBudget = Double.parseDouble(args[2]);
            printPlan(Planner.plan(d, p));
        } else if (cmd.equals("tsp")) { Planner.Plan pl = Planner.plan(d, new Planner.Params()); tspReport(pl); }
        else demo(outDir);
    }

    // ------------------------------------------------------------------ helpers
    static String join(String[] a, int from) { StringBuilder b = new StringBuilder(); for (int i = from; i < a.length; i++) { if (i > from) b.append(' '); b.append(a[i]); } return b.toString(); }
    static void head(String t) { System.out.println(); System.out.println("== " + t + " " + Fmt.rep('=', Math.max(3, 74 - t.length()))); }

    static void search(String text) {
        String q = DataCleaner.norm(text);
        System.out.println("Query: \"" + q + "\"");
        AhoCorasick ac = new AhoCorasick(keys); IntList hits = ac.search(q);
        System.out.println("[Aho-Corasick] stops mentioned (in order): ");
        for (int i = 0; i < hits.size(); i += 2) System.out.println("   " + d.name[hits.get(i)] + "  (ends at char " + hits.get(i + 1) + ")");
        StringBuilder all = new StringBuilder(); int[] start = new int[d.n];
        for (int i = 0; i < d.n; i++) { start[i] = all.length(); all.append(keys[i]).append('#'); }
        SuffixArray sa = new SuffixArray(all.toString());
        int[] rg = sa.range(q);
        boolean[] shown = new boolean[d.n]; int found = 0;
        for (int r = rg[0]; r < rg[1]; r++) { int s = stopAt(start, sa.sa[r]); if (!shown[s]) { shown[s] = true; found++; } }
        System.out.print("[Suffix array] stops whose name contains the whole query: " + (found == 0 ? "none" : ""));
        for (int i = 0; i < d.n; i++) if (shown[i]) System.out.print(d.name[i] + "; ");
        System.out.println();
        if (hits.size() == 0 && rg[1] == rg[0]) fuzzy(text);
    }
    static int stopAt(int[] start, int pos) { int lo = 0, hi = start.length - 1; while (lo < hi) { int mid = (lo + hi + 1) >>> 1; if (start[mid] <= pos) lo = mid; else hi = mid - 1; } return lo; }

    static void fuzzy(String name) {
        String k = DataCleaner.norm(name); System.out.println("Fuzzy lookup for \"" + name + "\":");
        int[] idx = new int[d.n]; long[] key = new long[d.n];
        for (int i = 0; i < d.n; i++) { idx[i] = i; key[i] = (long) (EditDistance.weighted(k, keys[i]) * 100); }
        Sorting.sortIdx(idx, key);
        for (int i = 0; i < 3 && i < d.n; i++)
            System.out.println("   " + Fmt.pad(d.name[idx[i]], 16) + " Levenshtein " + EditDistance.levenshtein(k, keys[idx[i]]) + "  Damerau " + EditDistance.damerau(k, keys[idx[i]]) + "  weighted " + Fmt.f(EditDistance.weighted(k, keys[idx[i]]), 1));
    }

    static int stopId(String name) { int id = DataCleaner.resolve(d, name, keys, d.n, map); if (id < 0) System.out.println("Unknown stop: " + name); return id; }

    static void route(String a, String b) {
        int u = stopId(a), v = stopId(b); if (u < 0 || v < 0) return;
        Graph g = new Graph(d.n); for (int i = 0; i < d.m; i++) g.addUndirected(d.eu[i], d.ev[i], d.eMin[i]);
        Graph.SP sp = g.dijkstra(u); int[] path = Graph.path(sp, v);
        System.out.print("Fastest road path (" + Fmt.f(sp.dist[v], 1) + " min): ");
        for (int i = 0; i < path.length; i++) System.out.print((i > 0 ? " > " : "") + d.name[path[i]]);
        System.out.println();
    }

    static void printPlan(Planner.Plan p) {
        System.out.println(Fmt.pad("#", 3) + Fmt.pad("Route", 36) + Fmt.lpad("stops", 6) + Fmt.lpad("one-way", 9) + Fmt.lpad("buses", 6) + Fmt.lpad("wait", 7) + Fmt.lpad("cost/day", 12));
        for (int r = 0; r < p.routes.length; r++) {
            Planner.Route ro = p.routes[r];
            System.out.println(Fmt.pad("" + (r + 1), 3) + Fmt.pad(p.d.name[ro.stops[0]] + " <-> " + p.d.name[ro.stops[ro.stops.length - 1]], 36) + Fmt.lpad("" + ro.stops.length, 6)
                    + Fmt.lpad(Fmt.f(ro.oneWayMin, 0) + " min", 9) + Fmt.lpad("" + ro.buses, 6) + Fmt.lpad(Fmt.f(ro.avgWait, 1), 7) + Fmt.lpad(Fmt.money(ro.dailyCost).substring(3), 12) + (ro.bottleneck ? "  <- bottleneck" : ""));
        }
        System.out.println("  stops covered " + Fmt.pct(p.stopCoverage) + " | direct demand " + Fmt.pct(p.directShare) + " | reachable " + Fmt.pct(p.reachShare)
                + " | avg wait " + Fmt.f(p.avgWait, 1) + " min | avg trip " + Fmt.f(p.avgTravel, 1) + " min");
        System.out.println("  fleet used " + p.busesAssigned + "/" + p.p.fleet + " (peak in service " + p.peakFleet + ", utilisation " + Fmt.pct(p.fleetUtil) + ") | cost " + Fmt.money(p.dailyCost) + "/day | peak unmet " + Fmt.pct(p.unmetPeakShare));
        if (p.notes.length() > 0) System.out.print("  note: " + p.notes);
    }

    static String tspReport(Planner.Plan pl) {
        Analysis.TspReport t = Analysis.hubLoop(pl, 12); StringBuilder s = new StringBuilder();
        s.append("Express loop through the 12 busiest hubs (travel-time metric closure)\n");
        s.append("  Held-Karp exact : ").append(Fmt.f(t.exact, 1)).append(" min   loop: ");
        for (int i = 0; i < t.exactTour.length; i++) s.append(i > 0 ? " > " : "").append(pl.d.name[t.hubs[t.exactTour[i]]]);
        s.append("\n  MST 2-approx    : ").append(Fmt.f(t.approx, 1)).append(" min   (ratio ").append(Fmt.f(t.approx / t.exact, 3)).append(", guarantee <= 2)\n");
        System.out.print(s); return s.toString();
    }

    // ------------------------------------------------------------------ full demo
    static void demo(String outDir) throws Exception {
        long t0 = System.currentTimeMillis();
        System.out.println("PUBLIC TRANSIT PLANNER  -  DSA-3 (25CS2103E)  -  engine uses no java.util");

        head("Module 1/2  Data cleaning (collect -> normalise -> dedupe -> fuzzy-repair -> validate)");
        System.out.println("stops  : " + d.stopsRaw + " raw rows -> " + d.stopsKept + " stops");
        System.out.println("links  : " + d.travelRaw + " raw rows -> " + d.travelKept + " road links (network connected: " + d.connected + ")");
        System.out.println("demand : " + d.demandRaw + " raw rows -> " + d.k + " undirected OD pairs, " + Fmt.f(d.totalDaily(), 0) + " trips/day");
        System.out.println("fixed by fuzzy matching: " + d.fuzzyFixed + ", duplicates merged: " + d.merged + ", rows dropped: " + d.dropped);
        System.out.print(d.log);

        head("Module 2  String algorithms on stop names");
        String q = "i want to go from ameerpet to hitec city via madhapur";
        search(q); search("nagar");
        String all = ""; for (int i = 0; i < d.n; i++) all += keys[i] + "#";
        IntList a1 = StringAlgos.kmp(all, "pur"), a2 = StringAlgos.zSearch(all, "pur"), a3 = StringAlgos.rabinKarp(all, "pur", new Rng(1));
        System.out.println("pattern \"pur\" in all stop names: KMP=" + a1.size() + " Z=" + a2.size() + " Rabin-Karp=" + a3.size() + " (hash false-positives: " + StringAlgos.rkCollisions + ")");
        System.out.println("longest repeated substring (suffix array + Kasai LCP): \"" + new SuffixArray(all).longestRepeated().replace("#", "").trim() + "\"");

        head("Module 3  Edit distance + alignment");
        fuzzy("Gachibwli"); fuzzy("Secundrabad");

        head("Module 6  Randomised primes (hash moduli) - Miller-Rabin");
        Rng pr = new Rng(11);
        System.out.println("random 31-bit prime used by Rabin-Karp/StrMap: " + NumberTheory.randomPrime(31, pr) + ", 61-bit: " + NumberTheory.randomPrime(61, pr));
        System.out.println("Carmichael 561: Fermat(2)=" + NumberTheory.fermatPasses(561, 2) + " but Miller-Rabin isPrime=" + NumberTheory.isPrime(561));

        head("Planning  baseline: fleet 50, no budget cap");
        Planner.Plan base = Planner.plan(d, new Planner.Params());
        printPlan(base);

        head("Module 3  Route overlap via sequence alignment (Needleman-Wunsch / Smith-Waterman)");
        for (int i = 0; i < base.routes.length && i < 4; i++) for (int j = i + 1; j < base.routes.length && j < 4; j++)
            System.out.println("  route " + (i + 1) + " vs " + (j + 1) + ": global " + Alignment.global(base.routes[i].stops, base.routes[j].stops, 2, -1, -1)
                    + ", shared corridor (local) " + Alignment.local(base.routes[i].stops, base.routes[j].stops, 2, -1, -1) / 2 + " stops");

        head("Module 4  Network flow");
        Analysis.FlowCheck fc = Analysis.peakFlow(base);
        System.out.println("peak-hour demand " + fc.total + " pax | Edmonds-Karp max-flow " + fc.ek + " | Dinic " + fc.dinic + " | min-cut capacity " + fc.cut
                + (fc.ek == fc.dinic && fc.dinic == fc.cut ? "   (all three agree)" : "   MISMATCH"));
        Analysis.Depot[] dp = Analysis.depots(base, 3, null); double dead = 0;
        for (Analysis.Depot x : dp) { int bs = 0; for (int v : x.busesFrom) bs += v; dead += x.deadMinutes; System.out.println("  depot at " + Fmt.pad(d.name[x.stop], 14) + " garages " + bs + " buses"); }
        System.out.println("min-cost-flow depot assignment: total dead-running " + Fmt.f(dead, 0) + " bus-minutes");

        head("Module 5  NP-hardness: hub loop (TSP)");
        String tsp = tspReport(base);

        head("Scenarios");
        String[] sn = {"Fleet 30", "Fleet 40", "Fleet 50 (baseline)", "Fleet 60", "Fleet 60, budget -30%"};
        Planner.Plan[] ps = new Planner.Plan[5]; int[] fl = {30, 40, 50, 60, 60};
        for (int i = 0; i < 5; i++) {
            Planner.Params p = new Planner.Params(); p.fleet = fl[i];
            if (i == 4) p.dailyBudget = 0.7 * ps[3].dailyCost;
            ps[i] = Planner.plan(d, p);
            System.out.println(Fmt.pad(sn[i], 24) + " routes " + ps[i].routes.length + " | direct " + Fmt.pct(ps[i].directShare) + " | wait " + Fmt.f(ps[i].avgWait, 1) + " min | trip " + Fmt.f(ps[i].avgTravel, 1) + " min | util " + Fmt.pct(ps[i].fleetUtil) + " | cost " + Fmt.money(ps[i].dailyCost));
        }

        head("Module 6  Monte Carlo + reservoir sampling");
        Simulator.Result sim = Simulator.run(base, 300000, 6, new Rng(2026));
        System.out.println("simulated wait " + Fmt.f(sim.simWait, 2) + " min (+/- " + Fmt.f(1.96 * sim.stderr, 2) + ") vs analytic " + Fmt.f(sim.analyticWait, 2) + " min  [" + sim.trials + " random passengers]");
        System.out.println("audit sample (uniform reservoir of the passenger stream):");
        for (String s : sim.audit) System.out.println("   " + s);

        head("Self-test");
        boolean ok = SelfTest.run();

        // ---- HTML report ----
        new File(outDir).mkdirs();
        StringBuilder sy = new StringBuilder();
        sy.append("<div class=scroll><table><tr><th>Syllabus module<th>Used in this project for<th>Class</tr>")
          .append("<tr><td>M1 TextHack-style engine<td>Query commands (search / fuzzy / route / plan), engine without java.util<td>Main</tr>")
          .append("<tr><td>M2 KMP, Z, Rabin-Karp<td>Pattern search in stop names; hash verified (Las Vegas)<td>StringAlgos</tr>")
          .append("<tr><td>M2 Aho-Corasick<td>Find every stop named in a free-text rider request<td>AhoCorasick</tr>")
          .append("<tr><td>M2 Suffix array + LCP<td>Substring/autocomplete lookup and repeated-name analysis<td>SuffixArray</tr>")
          .append("<tr><td>M3 Edit distance family<td>Repair typos while cleaning stops/links/demand<td>EditDistance, DataCleaner</tr>")
          .append("<tr><td>M3 Alignment<td>Detect overlapping routes (shared corridors)<td>Alignment</tr>")
          .append("<tr><td>M3 DP (allocation)<td>Split the fleet between routes to minimise waiting (O(R F&sup2;))<td>Planner.dpAllocate</tr>")
          .append("<tr><td>M3 Bitmask DP<td>Held-Karp exact hub loop<td>Tsp</tr>")
          .append("<tr><td>M4 Max-flow (Edmonds-Karp, Dinic)<td>Peak-hour capacity feasibility; cross-checked against the min cut<td>FlowNetwork, Analysis</tr>")
          .append("<tr><td>M4 Min-cost flow / assignment<td>Assign passengers to routes; assign buses to depots<td>Planner.assign, Analysis.depots</tr>")
          .append("<tr><td>M5 NP-hardness + approximation<td>Route selection = budgeted max-coverage (greedy, 1-1/e); TSP 2-approximation<td>Planner, Tsp</tr>")
          .append("<tr><td>M6 Randomised algorithms<td>Miller-Rabin primes for hashing, randomised quicksort, universal hashing<td>NumberTheory, Sorting, StrMap</tr>")
          .append("<tr><td>M6 Monte Carlo, reservoir sampling<td>Validate waiting time by simulating 300k riders; uniform audit sample<td>Simulator</tr>")
          .append("<tr><td>M6 Parallel prefix-sum / reduce<td>Cumulative demand weights for sampling (multi-threaded)<td>ParallelScan</tr></table></div>");
        StringBuilder cl = new StringBuilder("Raw rows -> kept: stops " + d.stopsRaw + "->" + d.stopsKept + ", links " + d.travelRaw + "->" + d.travelKept + ", demand rows " + d.demandRaw + "->" + d.k + " OD pairs\n"
                + "Fuzzy-repaired: " + d.fuzzyFixed + "   merged duplicates: " + d.merged + "   dropped invalid: " + d.dropped + "\n\n").append(d.log);
        String[] maps = new String[5];
        for (int i = 0; i < 5; i++) maps[i] = ReportWriter.kpis(ps[i]) + ReportWriter.mapSvg(ps[i]) + ReportWriter.stopList(ps[i]);
        double[] wv = new double[5], cv = new double[5], dv = new double[5]; String[] lb = {"F30", "F40", "F50", "F60", "F60-30%"};
        for (int i = 0; i < 5; i++) { wv[i] = ps[i].avgWait; cv[i] = ps[i].dailyCost / 1000; dv[i] = ps[i].directShare * 100; }
        String charts = "<div style='display:flex;flex-wrap:wrap;gap:12px'>" + ReportWriter.bars("Average waiting time (min)", lb, wv, "", 1) + ReportWriter.bars("Daily operating cost (Rs thousand)", lb, cv, "", 0) + ReportWriter.bars("Demand served directly (%)", lb, dv, "", 1) + "</div>";
        String valid = "Monte Carlo: simulated wait " + Fmt.f(sim.simWait, 2) + " min (95% CI +/- " + Fmt.f(1.96 * sim.stderr, 2) + ") vs analytic " + Fmt.f(sim.analyticWait, 2) + " min over " + sim.trials + " riders\n"
                + "Max-flow: Edmonds-Karp " + fc.ek + " = Dinic " + fc.dinic + " = min-cut " + fc.cut + " (peak demand " + fc.total + ")\n" + tsp + "Self-tests: " + (ok ? "all passed" : "FAILURES") + "\n\nAudit sample:\n";
        StringBuilder au = new StringBuilder(valid); for (String s : sim.audit) au.append("  ").append(s).append('\n');
        ReportWriter.write(outDir + "/report.html", "Public Transit Planner - Hyderabad (synthetic data)",
                new String[]{"Syllabus coverage", "1. Data collection and cleaning", "2. Plan and scenarios (click a tab)", "3. Scenario comparison", "4. Baseline route details", "5. Hourly timetable (baseline)", "6. Validation"},
                new String[]{sy.toString(), ReportWriter.pre(cl.toString()), ReportWriter.tabs(sn, maps), ReportWriter.scenarioTable(sn, ps) + charts, ReportWriter.routeTable(base), ReportWriter.timetable(base), ReportWriter.pre(au.toString())});
        System.out.println();
        System.out.println("Report written to " + outDir + "/report.html  (" + (System.currentTimeMillis() - t0) + " ms)");
    }
}
