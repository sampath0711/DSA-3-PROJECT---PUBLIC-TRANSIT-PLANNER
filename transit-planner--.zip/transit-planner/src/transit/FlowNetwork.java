package transit;

/** Module 4: flow network with Edmonds-Karp, Dinic, min-cut extraction and min-cost max-flow (SSP + SPFA). */
public final class FlowNetwork {
    public static final long INF = Long.MAX_VALUE / 4;
    public final int n; private final int[] head;
    private int[] nxt = new int[32], to = new int[32]; private long[] cap = new long[32], orig = new long[32], cost = new long[32];
    private int m;

    public FlowNetwork(int n) { this.n = n; head = new int[n]; for (int i = 0; i < n; i++) head[i] = -1; }

    /** Adds edge u->v and its residual twin; returns the forward edge id (twin is id^1). */
    public int addEdge(int u, int v, long c, long cst) {
        if (m + 2 > to.length) {
            int sz = to.length * 2;
            int[] a = new int[sz], b = new int[sz]; long[] x = new long[sz], y = new long[sz], z = new long[sz];
            System.arraycopy(nxt, 0, a, 0, m); System.arraycopy(to, 0, b, 0, m);
            System.arraycopy(cap, 0, x, 0, m); System.arraycopy(orig, 0, y, 0, m); System.arraycopy(cost, 0, z, 0, m);
            nxt = a; to = b; cap = x; orig = y; cost = z;
        }
        to[m] = v; cap[m] = orig[m] = c; cost[m] = cst; nxt[m] = head[u]; head[u] = m++;
        to[m] = u; cap[m] = orig[m] = 0; cost[m] = -cst; nxt[m] = head[v]; head[v] = m++;
        return m - 2;
    }
    public void reset() { System.arraycopy(orig, 0, cap, 0, m); }
    public long flowOn(int e) { return orig[e] - cap[e]; }
    public long residual(int e) { return cap[e]; }
    public int edgeCount() { return m / 2; }

    // ---- Edmonds-Karp: BFS shortest augmenting paths, O(V E^2) ----
    public long edmondsKarp(int s, int t) {
        long flow = 0; int[] prevE = new int[n]; int[] q = new int[n];
        while (true) {
            for (int i = 0; i < n; i++) prevE[i] = -1;
            prevE[s] = -2; int qh = 0, qt = 0; q[qt++] = s;
            while (qh < qt && prevE[t] == -1) {
                int u = q[qh++];
                for (int e = head[u]; e != -1; e = nxt[e])
                    if (cap[e] > 0 && prevE[to[e]] == -1) { prevE[to[e]] = e; q[qt++] = to[e]; }
            }
            if (prevE[t] == -1) break;
            long f = INF;
            for (int v = t; v != s; v = to[prevE[v] ^ 1]) f = Math.min(f, cap[prevE[v]]);
            for (int v = t; v != s; v = to[prevE[v] ^ 1]) { cap[prevE[v]] -= f; cap[prevE[v] ^ 1] += f; }
            flow += f;
        }
        return flow;
    }

    // ---- Dinic: blocking flows on BFS level graphs, O(V^2 E) ----
    private int[] level, iter;
    public long dinic(int s, int t) {
        long flow = 0; level = new int[n]; iter = new int[n];
        while (bfs(s, t)) {
            System.arraycopy(head, 0, iter, 0, n);
            long f;
            while ((f = dfs(s, t, INF)) > 0) flow += f;
        }
        return flow;
    }
    private boolean bfs(int s, int t) {
        for (int i = 0; i < n; i++) level[i] = -1;
        int[] q = new int[n]; int qh = 0, qt = 0; q[qt++] = s; level[s] = 0;
        while (qh < qt) {
            int u = q[qh++];
            for (int e = head[u]; e != -1; e = nxt[e])
                if (cap[e] > 0 && level[to[e]] < 0) { level[to[e]] = level[u] + 1; q[qt++] = to[e]; }
        }
        return level[t] >= 0;
    }
    private long dfs(int u, int t, long f) {
        if (u == t) return f;
        for (; iter[u] != -1; iter[u] = nxt[iter[u]]) {
            int e = iter[u], v = to[e];
            if (cap[e] > 0 && level[v] == level[u] + 1) {
                long d = dfs(v, t, Math.min(f, cap[e]));
                if (d > 0) { cap[e] -= d; cap[e ^ 1] += d; return d; }
            }
        }
        return 0;
    }

    /** After a max-flow: nodes reachable from s in the residual graph (the source side of a min cut). */
    public boolean[] sourceSide(int s) {
        boolean[] seen = new boolean[n]; int[] q = new int[n]; int qh = 0, qt = 0;
        q[qt++] = s; seen[s] = true;
        while (qh < qt) {
            int u = q[qh++];
            for (int e = head[u]; e != -1; e = nxt[e]) if (cap[e] > 0 && !seen[to[e]]) { seen[to[e]] = true; q[qt++] = to[e]; }
        }
        return seen;
    }
    /** Capacity of the cut (S, V\S) - equals the max-flow value by the max-flow min-cut theorem. */
    public long cutCapacity(boolean[] side) {
        long c = 0;
        for (int u = 0; u < n; u++) if (side[u])
            for (int e = head[u]; e != -1; e = nxt[e]) if ((e & 1) == 0 && !side[to[e]]) c += orig[e];
        return c;
    }

    // ---- Min-cost max-flow: successive shortest paths (SPFA handles negative residual costs) ----
    public long[] minCostMaxFlow(int s, int t) {
        long flow = 0, total = 0; long[] dist = new long[n]; int[] prevE = new int[n];
        boolean[] inq = new boolean[n]; int[] q = new int[n + 1];
        while (true) {
            for (int i = 0; i < n; i++) { dist[i] = INF; prevE[i] = -1; inq[i] = false; }
            int qh = 0, qt = 0; dist[s] = 0; q[qt++] = s; inq[s] = true;
            while (qh != qt) {
                int u = q[qh]; qh = (qh + 1) % (n + 1); inq[u] = false;
                for (int e = head[u]; e != -1; e = nxt[e])
                    if (cap[e] > 0 && dist[u] + cost[e] < dist[to[e]]) {
                        dist[to[e]] = dist[u] + cost[e]; prevE[to[e]] = e;
                        if (!inq[to[e]]) { inq[to[e]] = true; q[qt] = to[e]; qt = (qt + 1) % (n + 1); }
                    }
            }
            if (dist[t] >= INF) break;
            long f = INF;
            for (int v = t; v != s; v = to[prevE[v] ^ 1]) f = Math.min(f, cap[prevE[v]]);
            for (int v = t; v != s; v = to[prevE[v] ^ 1]) { cap[prevE[v]] -= f; cap[prevE[v] ^ 1] += f; }
            flow += f; total += f * dist[t];
        }
        return new long[]{flow, total};
    }
}
