package transit;

/** Module 6: Monte Carlo validation of waiting times + reservoir sampling of a trip stream. */
public final class Simulator {
    private Simulator() {}
    public static final class Result { public double simWait, analyticWait, stderr; public int trials; public String[] audit; }

    public static Result run(Planner.Plan pl, int trials, int auditSize, Rng rng) {
        TransitData d = pl.d; int R = pl.routes.length, NH = TransitData.NH;
        // departure timetable per route (minutes after midnight, sorted)
        double[][] dep = new double[R][];
        for (int r = 0; r < R; r++) {
            int cnt = 0; for (int h = 0; h < NH; h++) cnt += pl.routes[r].freq[h];
            dep[r] = new double[cnt]; int c = 0;
            for (int h = 0; h < NH; h++) for (int i = 0; i < pl.routes[r].freq[h]; i++) dep[r][c++] = (TransitData.H0 + h) * 60 + i * 60.0 / pl.routes[r].freq[h];
        }
        // weighted (OD, route) combinations -> prefix sums (parallel scan) -> binary-search sampling
        int cm = 0; for (int o = 0; o < d.k; o++) for (int r = 0; r < R; r++) if (pl.frac[o][r] > 0) cm++;
        int[] co = new int[cm], cr = new int[cm]; long[] w = new long[cm]; int c = 0;
        for (int o = 0; o < d.k; o++) for (int r = 0; r < R; r++) if (pl.frac[o][r] > 0) { co[c] = o; cr[c] = r; w[c] = Math.max(1, Math.round(d.odDaily[o] * pl.frac[o][r])); c++; }
        long[] pre = ParallelScan.inclusive(w, 4); long totalW = ParallelScan.sum(w, 4);
        double[] hcum = new double[NH]; double acc = 0;
        for (int h = 0; h < NH; h++) { acc += d.hourShare[h]; hcum[h] = acc; }

        double sum = 0, sq = 0; String[] audit = new String[auditSize]; int seen = 0;
        for (int t = 0; t < trials; t++) {
            long x = (long) (rng.nextDouble() * totalW);
            int lo = 0, hi = cm - 1;
            while (lo < hi) { int mid = (lo + hi) >>> 1; if (pre[mid] > x) hi = mid; else lo = mid + 1; }
            int o = co[lo], r = cr[lo];
            double u = rng.nextDouble(); int h = 0; while (h < NH - 1 && hcum[h] < u) h++;
            double arrive = (TransitData.H0 + h) * 60 + rng.nextDouble() * 60;
            int a = 0, b = dep[r].length;                    // first departure >= arrive
            while (a < b) { int mid = (a + b) >>> 1; if (dep[r][mid] >= arrive) b = mid; else a = mid + 1; }
            double wait = a < dep[r].length ? dep[r][a] - arrive
                    : Math.max(0, dep[r][dep[r].length - 1] + 60.0 / pl.routes[r].freq[NH - 1] - arrive);   // service ends ~23:00: assume last headway continues
            sum += wait; sq += wait * wait;
            // reservoir sampling (Algorithm R): uniform sample of size auditSize from the stream
            String rec = d.name[d.odU[o]] + " -> " + d.name[d.odV[o]] + " | route " + (r + 1) + " | " + (TransitData.H0 + h) + ":" + (arrive % 60 < 10 ? "0" : "") + Fmt.f(arrive % 60, 0) + " | wait " + Fmt.f(wait, 1) + " min";
            if (seen < auditSize) audit[seen] = rec; else { int j = rng.nextInt(seen + 1); if (j < auditSize) audit[j] = rec; }
            seen++;
        }
        Result res = new Result(); res.trials = trials; res.simWait = sum / trials;
        res.stderr = Math.sqrt(Math.max(0, sq / trials - res.simWait * res.simWait) / trials); res.audit = audit;
        double an = 0, tw = 0;
        for (int q = 0; q < cm; q++) {
            for (int h = 0; h < NH; h++) {
                double wt = w[q] * d.hourShare[h]; an += wt * 30.0 / pl.routes[cr[q]].freq[h]; tw += wt;
            }
        }
        res.analyticWait = an / tw;
        return res;
    }
}
