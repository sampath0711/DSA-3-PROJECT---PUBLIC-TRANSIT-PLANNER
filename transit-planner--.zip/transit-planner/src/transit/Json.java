package transit;

/** Hand-built JSON writer (no libraries): turns plans and static data into API responses. */
public final class Json {
    private Json() {}

    public static String s(String v) {
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            if (c == '"' || c == '\\') b.append('\\').append(c); else if (c < 32) b.append(' '); else b.append(c);
        }
        return b.append('"').toString();
    }
    static String ints(int[] a) { StringBuilder b = new StringBuilder("["); for (int i = 0; i < a.length; i++) { if (i > 0) b.append(','); b.append(a[i]); } return b.append(']').toString(); }
    static String dbl(double[] a, int dec) { StringBuilder b = new StringBuilder("["); for (int i = 0; i < a.length; i++) { if (i > 0) b.append(','); b.append(Fmt.f(a[i], dec)); } return b.append(']').toString(); }
    static String err(String m) { return "{\"ok\":false,\"error\":" + s(m) + "}"; }

    /** Stops [name,x,y,weight] and road links [a,b] - drawn by the browser. */
    public static String statics(TransitData d) {
        StringBuilder b = new StringBuilder("{\"S\":[");
        for (int i = 0; i < d.n; i++) { if (i > 0) b.append(','); b.append('[').append(s(d.name[i])).append(',').append(Fmt.f(d.x[i], 2)).append(',').append(Fmt.f(d.y[i], 2)).append(',').append(Fmt.f(d.weight[i], 0)).append(']'); }
        b.append("],\"E\":[");
        for (int i = 0; i < d.m; i++) { if (i > 0) b.append(','); b.append('[').append(d.eu[i]).append(',').append(d.ev[i]).append(']'); }
        return b.append("]}").toString();
    }

    /** Full plan: KPIs, routes (stops, cumulative minutes) and per-route hourly timetable. */
    public static String plan(Planner.Plan p) {
        StringBuilder b = new StringBuilder("{");
        b.append("\"F\":").append(p.p.fleet).append(",\"B\":").append(Fmt.f(p.p.dailyBudget, 0))
         .append(",\"cov\":").append(Fmt.f(p.stopCoverage, 4)).append(",\"direct\":").append(Fmt.f(p.directShare, 4)).append(",\"reach\":").append(Fmt.f(p.reachShare, 4))
         .append(",\"wait\":").append(Fmt.f(p.avgWait, 2)).append(",\"trip\":").append(Fmt.f(p.avgTravel, 2)).append(",\"util\":").append(Fmt.f(p.fleetUtil, 4))
         .append(",\"peak\":").append(p.peakFleet).append(",\"unmet\":").append(Fmt.f(p.unmetPeakShare, 4)).append(",\"cost\":").append(Fmt.f(p.dailyCost, 0))
         .append(",\"hf\":").append(ints(p.hourFleet)).append(",\"R\":[");
        for (int r = 0; r < p.routes.length; r++) {
            Planner.Route ro = p.routes[r]; if (r > 0) b.append(',');
            b.append("{\"st\":").append(ints(ro.stops)).append(",\"cum\":").append(dbl(ro.cum, 2)).append(",\"T\":").append(Fmt.f(ro.roundTripMin, 2)).append(",\"pos\":").append(ints(ro.posOf)).append('}');
        }
        b.append("],\"rs\":[");
        for (int r = 0; r < p.routes.length; r++) {
            Planner.Route ro = p.routes[r]; if (r > 0) b.append(',');
            b.append("{\"freq\":").append(ints(ro.freq)).append(",\"bn\":").append(ints(ro.busesNeeded)).append(",\"cost\":").append(Fmt.f(ro.dailyCost, 0)).append(",\"wait\":").append(Fmt.f(ro.avgWait, 2))
             .append(",\"buses\":").append(ro.buses).append(",\"demand\":").append(Fmt.f(ro.dailyDemand, 0)).append(",\"pk\":").append(Fmt.f(ro.peakLoad, 1)).append(",\"cap\":").append(Fmt.f(ro.peakCap, 1)).append('}');
        }
        return b.append("]}").toString();
    }

    /** Admin stop finder: fuzzy name lookup + the routes of this plan that serve the stop. */
    public static String find(Planner.Plan p, String q) {
        int[] dist = new int[1]; int id = Journey.resolve(p.d, q, dist);
        if (id < 0) return "{\"error\":\"No stop with a similar name.\"}";
        String how = dist[0] < 0 ? "match" : "closest match, " + dist[0] + " edit" + (dist[0] == 1 ? "" : "s") + " away";
        StringBuilder rs = new StringBuilder("[");
        boolean first = true;
        for (int r = 0; r < p.routes.length; r++) if (p.routes[r].posOf[id] >= 0) { if (!first) rs.append(','); rs.append(r + 1); first = false; }
        return "{\"name\":" + s(p.d.name[id]) + ",\"how\":" + s(how) + ",\"routes\":" + rs.append(']') + "}";
    }
}
