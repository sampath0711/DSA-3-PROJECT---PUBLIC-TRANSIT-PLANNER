package transit;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

/**
 * Web server for the Passenger and Admin portals. Uses only the JDK's built-in com.sun.net.httpserver
 * (no frameworks, no java.util). The browser page (web/index.html) only draws what these endpoints return.
 *
 *  public : GET /  /api/static  /api/live  /api/trip?from=&to=&time=HH:MM  /api/board?stop=&time=HH:MM
 *  admin  : POST /api/login?pin=   then header X-Token:  GET /api/draft?fleet=&budget=  GET /api/find?q=  POST /api/publish?fleet=&budget=
 *
 * Run:  java -cp out transit.Server        options: -Dport=8080 -Dpin=1234 -Ddata=data -Dweb=web
 */
public final class Server {
    private static TransitData d;
    private static Planner.Plan live, draft;
    private static Journey journey;
    private static String pin, token, webDir;

    public static void main(String[] args) throws Exception {
        String dataDir = System.getProperty("data", "data"); webDir = System.getProperty("web", "web");
        int port = Integer.parseInt(System.getProperty("port", "8080")); pin = System.getProperty("pin", "1234");
        d = DataCleaner.load(dataDir);
        live = Planner.plan(d, new Planner.Params()); journey = new Journey(live);
        HttpServer srv = HttpServer.create(new InetSocketAddress(port), 0);
        srv.createContext("/", Server::handle);
        srv.setExecutor(null);                               // one request at a time: no shared-state races
        srv.start();
        System.out.println("Transit portal running at http://localhost:" + port + "   (admin PIN: " + pin + ")  - press Ctrl+C to stop");
    }

    private static void handle(HttpExchange ex) throws IOException {
        try {
            String path = ex.getRequestURI().getPath(), q = ex.getRequestURI().getRawQuery(), m = ex.getRequestMethod();
            if (path.equals("/") || path.equals("/index.html")) { page(ex); return; }
            if (!path.startsWith("/api/")) { send(ex, 404, "text/plain; charset=utf-8", "Not found"); return; }
            boolean admin = path.equals("/api/draft") || path.equals("/api/publish") || path.equals("/api/find");
            if (admin && (token == null || !token.equals(ex.getRequestHeaders().getFirst("X-Token")))) { send(ex, 401, json(), "{\"error\":\"Not signed in\"}"); return; }
            String r;
            if (path.equals("/api/static")) r = Json.statics(d);
            else if (path.equals("/api/live")) r = Json.plan(live);
            else if (path.equals("/api/board")) r = journey.board(param(q, "stop"), parseTime(param(q, "time")));
            else if (path.equals("/api/trip")) r = journey.trip(param(q, "from"), param(q, "to"), parseTime(param(q, "time")));
            else if (path.equals("/api/login")) {
                if (!m.equals("POST") || !pin.equals(param(q, "pin"))) { send(ex, 401, json(), "{\"error\":\"Wrong PIN\"}"); return; }
                Rng rg = new Rng(System.nanoTime()); token = Long.toHexString(rg.nextLong()) + Long.toHexString(rg.nextLong());
                r = "{\"token\":\"" + token + "\"}";
            } else if (path.equals("/api/find")) r = Json.find(draft != null ? draft : live, param(q, "q"));
            else if (path.equals("/api/draft") || path.equals("/api/publish")) {
                if (path.equals("/api/publish") && !m.equals("POST")) { send(ex, 405, json(), "{\"error\":\"Use POST\"}"); return; }
                Planner.Params p = new Planner.Params();
                p.fleet = Integer.parseInt(param(q, "fleet")); String bg = param(q, "budget");
                p.dailyBudget = (bg == null || bg.equals("none")) ? 1e12 : Double.parseDouble(bg);
                try {
                    Planner.Plan pl = Planner.plan(d, p);
                    if (path.equals("/api/publish")) { live = pl; journey = new Journey(pl); } else draft = pl;
                    r = Json.plan(pl);
                } catch (IllegalStateException e) { r = "{\"error\":" + Json.s(e.getMessage()) + "}"; }
            } else { send(ex, 404, json(), "{\"error\":\"Unknown endpoint\"}"); return; }
            send(ex, 200, json(), r);
        } catch (RuntimeException e) {
            send(ex, 400, json(), "{\"error\":" + Json.s("Bad request: " + e.getMessage()) + "}");
        }
    }

    private static String json() { return "application/json; charset=utf-8"; }

    private static void page(HttpExchange ex) throws IOException {
        try (FileInputStream in = new FileInputStream(webDir + "/index.html")) {
            byte[] b = in.readAllBytes();
            ex.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
            ex.sendResponseHeaders(200, b.length);
            try (OutputStream os = ex.getResponseBody()) { os.write(b); }
        } catch (IOException e) {
            send(ex, 500, "text/plain; charset=utf-8", "Cannot read " + webDir + "/index.html - run the server from the project folder.");
        }
    }
    private static void send(HttpExchange ex, int code, String type, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", type); ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.sendResponseHeaders(code, b.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(b); }
    }
    private static String param(String q, String key) {
        if (q == null) return null;
        int pos = 0;
        while (pos <= q.length()) {
            int amp = q.indexOf('&', pos); if (amp < 0) amp = q.length();
            int eq = q.indexOf('=', pos);
            if (eq >= 0 && eq < amp && q.substring(pos, eq).equals(key)) return URLDecoder.decode(q.substring(eq + 1, amp), StandardCharsets.UTF_8);
            pos = amp + 1;
        }
        return null;
    }
    private static double parseTime(String s) {
        try { int c = s.indexOf(':'); return Integer.parseInt(s.substring(0, c)) * 60 + Integer.parseInt(s.substring(c + 1)); }
        catch (RuntimeException e) { return 480; }
    }
}
