package transit;

/**
 * Passenger trip planner: Dijkstra on the (stop, route) expanded graph, then real "next bus" times
 * from the timetable. One Journey object belongs to one published plan.
 */
public final class Journey {
    private final Planner.Plan pl; private final TransitData d; private final int n;
    private final Graph tg; private final int[] base, routeOf; private final Graph.SP[] cache;

    public Journey(Planner.Plan pl) {
        this.pl = pl; d = pl.d; n = d.n; int R = pl.routes.length;
        base = new int[R]; int nodes = n;
        for (int r = 0; r < R; r++) { base[r] = nodes; nodes += pl.routes[r].stops.length; }
        routeOf = new int[nodes]; for (int i = 0; i < nodes; i++) routeOf[i] = -1;
        tg = new Graph(nodes); cache = new Graph.SP[n];
        for (int r = 0; r < R; r++) {
            Planner.Route ro = pl.routes[r];
            for (int i = 0; i < ro.stops.length; i++) {
                int node = base[r] + i; routeOf[node] = r;
                tg.addEdge(ro.stops[i], node, ro.avgWait);          // board: wait half a headway
                tg.addEdge(node, ro.stops[i], pl.p.egress);         // alight / walk
                if (i + 1 < ro.stops.length) { double seg = ro.cum[i + 1] - ro.cum[i]; tg.addEdge(node, node + 1, seg); tg.addEdge(node + 1, node, seg); }
            }
        }
    }

    /** Exact name, then substring, then nearest by Damerau-Levenshtein (<= 3 edits). dist[0] = -1 unless fuzzy. */
    public static int resolve(TransitData d, String q, int[] dist) {
        String k = DataCleaner.norm(q); dist[0] = -1;
        if (k.isEmpty()) return -1;
        for (int i = 0; i < d.n; i++) if (DataCleaner.norm(d.name[i]).equals(k)) return i;
        for (int i = 0; i < d.n; i++) if (DataCleaner.norm(d.name[i]).contains(k)) return i;
        int best = 4, bi = -1;
        for (int i = 0; i < d.n; i++) { int dd = EditDistance.damerau(k, DataCleaner.norm(d.name[i])); if (dd < best) { best = dd; bi = i; } }
        if (bi >= 0) dist[0] = best;
        return bi;
    }

    /** Next k times (minutes after midnight) a bus of route r passes stop 'from' heading towards 'to', at or after t. */
    private double[] nextBuses(int r, int from, int to, double t, int k) {
        Planner.Route ro = pl.routes[r]; double ow = ro.cum[ro.stops.length - 1];
        int pf = ro.posOf[from], pt = ro.posOf[to];
        double off = pt > pf ? ro.cum[pf] : ow - ro.cum[pf];
        double[] out = new double[k]; int c = 0;
        for (int h = 0; h < Planner.NH && c < k; h++)
            for (int j = 0; j < ro.freq[h] && c < k; j++) {
                double m = (TransitData.H0 + h) * 60 + j * 60.0 / ro.freq[h] + off;
                if (m >= t) out[c++] = m;
            }
        double[] res = new double[c]; System.arraycopy(out, 0, res, 0, c);
        return res;
    }

    public String trip(String fromQ, String toQ, double t0) {
        int[] dist = new int[1];
        int a = resolve(d, fromQ, dist), b = resolve(d, toQ, dist);
        if (a < 0) return Json.err("We could not find the starting stop. Pick a name from the suggestions.");
        if (b < 0) return Json.err("We could not find the destination. Pick a name from the suggestions.");
        if (a == b) return Json.err("Start and destination are the same place.");
        if (cache[a] == null) cache[a] = tg.dijkstra(a);
        Graph.SP s = cache[a];
        if (s.dist[b] >= Graph.INF) return Json.err("No bus connects " + d.name[a] + " and " + d.name[b] + " yet.");
        IntList ns = new IntList();
        for (int x = b; x != -1; x = s.parent[x]) ns.add(x);
        ns.reverse();

        t0 = Math.max(300, t0); double t = t0, lastArr = 0; int curR = -1, curFrom = -1; double curT0 = 0; int legs = 0;
        StringBuilder lj = new StringBuilder();
        for (int i = 1; i < ns.size(); i++) {
            int u = ns.get(i - 1), v = ns.get(i);
            if (u < n && v >= n) { curR = routeOf[v]; curFrom = u; curT0 = pl.routes[curR].cum[v - base[curR]]; }
            else if (u >= n && v < n) {
                Planner.Route ro = pl.routes[curR];
                double ride = Math.abs(ro.cum[u - base[curR]] - curT0);
                double[] nb = nextBuses(curR, curFrom, v, t, 3); boolean late = false;
                if (nb.length == 0) { nb = nextBuses(curR, curFrom, v, 0, 3); for (int k = 0; k < nb.length; k++) nb[k] += 1440; late = true; }
                double board = nb[0], arr = board + ride; t = arr + 2; lastArr = arr;
                int p1 = ro.posOf[curFrom], p2 = ro.posOf[v], lo = Math.min(p1, p2), hi = Math.max(p1, p2);
                int[] seg = new int[hi - lo + 1]; for (int k = lo; k <= hi; k++) seg[k - lo] = ro.stops[k];
                if (legs++ > 0) lj.append(',');
                lj.append("{\"r\":").append(curR).append(",\"from\":").append(Json.s(d.name[curFrom])).append(",\"to\":").append(Json.s(d.name[v]))
                  .append(",\"ride\":").append(Fmt.f(ride, 1)).append(",\"board\":").append(Fmt.f(board, 1)).append(",\"arr\":").append(Fmt.f(arr, 1))
                  .append(",\"late\":").append(late).append(",\"nb\":").append(Json.dbl(nb, 1)).append(",\"stops\":").append(Json.ints(seg)).append('}');
            }
        }
        return "{\"ok\":true,\"a\":" + a + ",\"b\":" + b + ",\"from\":" + Json.s(d.name[a]) + ",\"to\":" + Json.s(d.name[b])
                + ",\"arrive\":" + Fmt.f(lastArr, 1) + ",\"total\":" + Fmt.f(lastArr - t0, 1) + ",\"legs\":[" + lj + "]}";
    }

    /** Departure board: for every route serving a stop, the next buses in each direction. */
    public String board(String q, double t) {
        int[] dist = new int[1]; int id = resolve(d, q, dist);
        if (id < 0) return Json.err("We could not find that stop. Pick a name from the suggestions.");
        StringBuilder b = new StringBuilder("{\"ok\":true,\"stop\":").append(Json.s(d.name[id])).append(",\"rows\":["); boolean first = true;
        for (int r = 0; r < pl.routes.length; r++) {
            Planner.Route ro = pl.routes[r]; int p = ro.posOf[id], len = ro.stops.length; if (p < 0) continue;
            for (int dir = 0; dir < 2; dir++) {
                if (dir == 0 && p == len - 1) continue; if (dir == 1 && p == 0) continue;
                int target = dir == 0 ? ro.stops[len - 1] : ro.stops[0];
                if (!first) b.append(','); first = false;
                b.append("{\"r\":").append(r).append(",\"toward\":").append(Json.s(d.name[target])).append(",\"times\":").append(Json.dbl(nextBuses(r, id, target, t, 4), 1)).append('}');
            }
        }
        return b.append("]}").toString();
    }
}
