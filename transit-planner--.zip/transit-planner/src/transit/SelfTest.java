package transit;

/** Randomised cross-checks of every algorithm against a slow-but-obviously-correct baseline. */
public final class SelfTest {
    private SelfTest() {}
    private static int pass, fail;
    private static void check(String what, boolean ok) { if (ok) pass++; else { fail++; System.out.println("  FAIL: " + what); } }

    private static String randStr(Rng r, int len, int alpha) { StringBuilder b = new StringBuilder(); for (int i = 0; i < len; i++) b.append((char) ('a' + r.nextInt(alpha))); return b.toString(); }
    private static boolean same(IntList a, IntList b) { if (a.size() != b.size()) return false; for (int i = 0; i < a.size(); i++) if (a.get(i) != b.get(i)) return false; return true; }

    public static boolean run() {
        pass = 0; fail = 0; Rng r = new Rng(99);
        // --- Module 2: string algorithms vs naive ---
        for (int t = 0; t < 300; t++) {
            String text = randStr(r, 1 + r.nextInt(60), 3), pat = randStr(r, 1 + r.nextInt(4), 3);
            IntList nv = StringAlgos.naive(text, pat);
            check("KMP", same(nv, StringAlgos.kmp(text, pat)));
            check("Z", same(nv, StringAlgos.zSearch(text, pat)));
            check("Rabin-Karp", same(nv, StringAlgos.rabinKarp(text, pat, r)));
            String[] pats = {randStr(r, 2, 3), randStr(r, 3, 3), randStr(r, 1, 3)};
            IntList ac = new AhoCorasick(pats).search(text); int naiveCount = 0;
            for (String p : pats) naiveCount += StringAlgos.naive(text, p).size();
            check("Aho-Corasick count", ac.size() / 2 == naiveCount);
            SuffixArray sa = new SuffixArray(text); boolean ordered = true;
            for (int i = 1; i < sa.sa.length; i++) if (text.substring(sa.sa[i - 1]).compareTo(text.substring(sa.sa[i])) >= 0) ordered = false;
            check("suffix array order", ordered);
            int[] rg = sa.range(pat); check("SA range", rg[1] - rg[0] == nv.size());
            boolean lcpOk = true;
            for (int i = 1; i < sa.sa.length; i++) { int h = 0; while (sa.sa[i] + h < text.length() && sa.sa[i - 1] + h < text.length() && text.charAt(sa.sa[i] + h) == text.charAt(sa.sa[i - 1] + h)) h++; if (h != sa.lcp[i]) lcpOk = false; }
            check("LCP", lcpOk);
        }
        // --- Module 3: edit distance, alignment ---
        check("lev kitten/sitting", EditDistance.levenshtein("kitten", "sitting") == 3);
        check("damerau transposition", EditDistance.damerau("ca", "ac") == 1 && EditDistance.levenshtein("ca", "ac") == 2);
        check("weighted vowel", Math.abs(EditDistance.weighted("metro", "mitro") - 0.5) < 1e-9);
        check("NW identical", Alignment.global(new int[]{1, 2, 3}, new int[]{1, 2, 3}, 2, -1, -1) == 6);
        check("SW shared corridor", Alignment.local(new int[]{9, 1, 2, 3, 8}, new int[]{7, 1, 2, 3, 6}, 2, -1, -1) == 6);
        // --- Module 6: primes, scan, sort ---
        for (int n = 0; n < 5000; n++) { boolean p = n > 1; for (int q = 2; q * q <= n; q++) if (n % q == 0) p = false; check("MR " + n, NumberTheory.isPrime(n) == p); }
        check("561 composite yet Fermat-fooled", !NumberTheory.isPrime(561) && NumberTheory.fermatPasses(561, 2) && NumberTheory.fermatPasses(561, 5));
        check("2^61-1 prime", NumberTheory.isPrime((1L << 61) - 1));
        for (int t = 0; t < 50; t++) {
            int n = 1 + r.nextInt(500); long[] a = new long[n]; for (int i = 0; i < n; i++) a[i] = r.nextInt(1000);
            long[] ps = ParallelScan.inclusive(a, 4); long s = 0; boolean ok = true;
            for (int i = 0; i < n; i++) { s += a[i]; if (ps[i] != s) ok = false; }
            check("parallel scan", ok && ParallelScan.sum(a, 3) == s);
            int p2 = 1 << (1 + r.nextInt(8)); long[] b = new long[p2]; for (int i = 0; i < p2; i++) b[i] = r.nextInt(100);
            long[] bl = ParallelScan.blellochExclusive(b); long run = 0; boolean ok2 = true;
            for (int i = 0; i < p2; i++) { if (bl[i] != run) ok2 = false; run += b[i]; }
            check("Blelloch scan", ok2);
            int[] arr = new int[n]; for (int i = 0; i < n; i++) arr[i] = r.nextInt(50);
            Sorting.sort(arr); boolean sorted = true; for (int i = 1; i < n; i++) if (arr[i - 1] > arr[i]) sorted = false; check("quicksort", sorted);
        }
        StrMap sm = new StrMap(r); for (int i = 0; i < 1000; i++) sm.put("k" + i, i);
        boolean hm = sm.size() == 1000; for (int i = 0; i < 1000; i++) if (sm.get("k" + i, -1) != i) hm = false; check("StrMap", hm && sm.get("zz", -1) == -1);
        // --- graphs: Dijkstra vs Bellman-Ford ---
        for (int t = 0; t < 40; t++) {
            int n = 2 + r.nextInt(12); Graph g = new Graph(n); int m = n * 3; int[] eu = new int[m], ev = new int[m]; double[] ew = new double[m];
            for (int i = 0; i < m; i++) { eu[i] = r.nextInt(n); ev[i] = r.nextInt(n); ew[i] = 1 + r.nextInt(20); g.addEdge(eu[i], ev[i], ew[i]); }
            double[] bf = new double[n]; for (int i = 0; i < n; i++) bf[i] = Graph.INF; bf[0] = 0;
            for (int it = 0; it < n; it++) for (int i = 0; i < m; i++) if (bf[eu[i]] + ew[i] < bf[ev[i]]) bf[ev[i]] = bf[eu[i]] + ew[i];
            Graph.SP sp = g.dijkstra(0); boolean ok = true; for (int i = 0; i < n; i++) if (Math.abs(sp.dist[i] - bf[i]) > 1e-9) ok = false; check("Dijkstra", ok);
        }
        // --- Module 4: EK == Dinic == min-cut; MCMF on a known instance ---
        for (int t = 0; t < 60; t++) {
            int n = 4 + r.nextInt(8); FlowNetwork f = new FlowNetwork(n);
            for (int i = 0; i < n * 3; i++) { int u = r.nextInt(n), v = r.nextInt(n); if (u != v) f.addEdge(u, v, 1 + r.nextInt(30), 0); }
            long a = f.edmondsKarp(0, n - 1); f.reset(); long b = f.dinic(0, n - 1);
            check("EK==Dinic", a == b); check("max-flow == min-cut", f.cutCapacity(f.sourceSide(0)) == b);
        }
        FlowNetwork mc = new FlowNetwork(4); mc.addEdge(0, 1, 2, 1); mc.addEdge(0, 2, 2, 5); mc.addEdge(1, 3, 1, 1); mc.addEdge(2, 3, 3, 1); mc.addEdge(1, 2, 1, 1);
        long[] res = mc.minCostMaxFlow(0, 3); check("MCMF flow 4", res[0] == 4); check("MCMF cost 17", res[1] == 17);
        // --- Module 5: Held-Karp vs brute force, 2-approx bound ---
        for (int t = 0; t < 25; t++) {
            int n = 4 + r.nextInt(4); double[] px = new double[n], py = new double[n]; double[][] d = new double[n][n];
            for (int i = 0; i < n; i++) { px[i] = r.nextDouble() * 50; py[i] = r.nextDouble() * 50; }
            for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) d[i][j] = Math.hypot(px[i] - px[j], py[i] - py[j]);
            double hk = Tsp.heldKarp(d).cost, br = Tsp.brute(d), ap = Tsp.mstApprox(d).cost;
            check("Held-Karp == brute", Math.abs(hk - br) < 1e-6); check("MST 2-approx", ap <= 2 * br + 1e-6 && ap >= br - 1e-6);
        }
        System.out.println("  self-test: " + pass + " checks passed, " + fail + " failed");
        return fail == 0;
    }
}
