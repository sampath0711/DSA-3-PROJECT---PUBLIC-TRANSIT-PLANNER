package transit;

/** Tiny formatting helpers (avoids java.util.Formatter/Locale). */
public final class Fmt {
    private Fmt() {}
    public static String f(double v, int dec) {
        double sc = Math.pow(10, dec); long r = Math.round(Math.abs(v) * sc);
        String t = Long.toString(r);
        while (t.length() <= dec) t = "0" + t;
        String res = dec > 0 ? t.substring(0, t.length() - dec) + "." + t.substring(t.length() - dec) : t;
        return (v < 0 && r != 0 ? "-" : "") + res;
    }
    public static String money(double v) {
        String s = Long.toString(Math.round(v)); StringBuilder b = new StringBuilder();
        int c = 0;
        for (int i = s.length() - 1; i >= 0; i--) { b.append(s.charAt(i)); if (++c % 3 == 0 && i > 0) b.append(','); }
        return "Rs " + b.reverse();
    }
    public static String pct(double v) { return f(v * 100, 1) + "%"; }
    public static String pad(String s, int w) { StringBuilder b = new StringBuilder(s); while (b.length() < w) b.append(' '); return b.toString(); }
    public static String lpad(String s, int w) { StringBuilder b = new StringBuilder(); for (int i = s.length(); i < w; i++) b.append(' '); return b.append(s).toString(); }
    public static String rep(char c, int n) { StringBuilder b = new StringBuilder(); for (int i = 0; i < n; i++) b.append(c); return b.toString(); }
}
