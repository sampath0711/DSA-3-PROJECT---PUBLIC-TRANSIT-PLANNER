package transit;

/** Extra analyses that tie the plan back to the syllabus: flows (Module 4), NP-hardness (Module 5). */
public final class Analysis {
    private Analysis() {}

    public static final class FlowCheck { public long ek, dinic, cut, total; public String bottlenecks = ""; }

    /** Peak-hour feasibility: pure max-flow (no costs) solved by Edmonds-Karp AND Dinic, verified by a min cut. */
    public static FlowCheck peakFlow(Planner.Plan pl) {
        TransitData d = pl.d; Planner.Route[] rs = pl.routes; int R = rs.length;
        IntList od = new IntList();
        for (int o = 0; o < d.k; o++) {
            boolean dir = false;
            for (int r = 0; r < R; r++) if (rs[r].posOf[d.odU[o]] >= 0 && rs[r].posOf[d.odV[o]] >= 0) dir = true;
            if (dir) od.add(o);
        }
        int K = od.size(), S = 0, T = K + R + 1; double ms = d.maxShare(); FlowCheck fc = new FlowCheck();
        FlowNetwork f = new FlowNetwork(K + R + 2);
        for (int a = 0; a < K; a++) {
            int o = od.get(a); long dem = (long) Math.ceil(d.odDaily[o] * ms); fc.total += dem;
            f.addEdge(S, 1 + a, dem, 0);
            for (int r = 0; r < R; r++) if (rs[r].posOf[d.odU[o]] >= 0 && rs[r].posOf[d.odV[o]] >= 0) f.addEdge(1 + a, K + 1 + r, dem, 0);
        }
        for (int r = 0; r < R; r++) {
            int fm = 0; for (int h = 0; h < Planner.NH; h++) fm = Math.max(fm, rs[r].freq[h]);
            f.addEdge(K + 1 + r, T, (long) Math.floor(2.0 * fm * pl.p.busCap * pl.p.loadFactor), 0);
        }
        fc.ek = f.edmondsKarp(S, T); f.reset(); fc.dinic = f.dinic(S, T);
        boolean[] side = f.sourceSide(S); fc.cut = f.cutCapacity(side);
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < R; r++) if (fc.total > fc.dinic && side[K + 1 + r] && f.residual(f.edgeCount() * 2 - 2 * (R - r)) == 0) sb.append(r + 1).append(' ');
        fc.bottlenecks = sb.toString().trim();
        return fc;
    }

    public static final class Depot { public int stop; public int[] busesFrom; public double deadMinutes; }

    /** Which depot should garage each route's buses? Min-cost flow; depots by farthest-first traversal. */
    public static Depot[] depots(Planner.Plan pl, int count, int[] busesPerDepotOut) {
        TransitData d = pl.d; int R = pl.routes.length, n = d.n;
        int[] dep = new int[count]; int first = 0;
        for (int i = 1; i < n; i++) if (d.weight[i] > d.weight[first]) first = i;
        dep[0] = first;
        for (int c = 1; c < count; c++) {
            int best = -1; double bd = -1;
            for (int s = 0; s < n; s++) {
                double mn = 1e18; for (int j = 0; j < c; j++) mn = Math.min(mn, pl.sp[dep[j]].dist[s]);
                if (mn > bd) { bd = mn; best = s; }
            }
            dep[c] = best;
        }
        int S = 0, T = R + count + 1; FlowNetwork f = new FlowNetwork(R + count + 2);
        int cap = (int) Math.ceil(pl.p.fleet / (double) count) + 2;
        int[][] e = new int[R][count];
        for (int r = 0; r < R; r++) {
            f.addEdge(S, 1 + r, pl.routes[r].buses, 0);
            int term = pl.routes[r].stops[0];
            for (int j = 0; j < count; j++) e[r][j] = f.addEdge(1 + r, R + 1 + j, pl.routes[r].buses, Math.round(10 * pl.sp[dep[j]].dist[term]));
        }
        for (int j = 0; j < count; j++) f.addEdge(R + 1 + j, T, cap, 0);
        f.minCostMaxFlow(S, T);
        Depot[] out = new Depot[count];
        for (int j = 0; j < count; j++) { out[j] = new Depot(); out[j].stop = dep[j]; out[j].busesFrom = new int[R]; }
        for (int r = 0; r < R; r++) for (int j = 0; j < count; j++) {
            int fl = (int) f.flowOn(e[r][j]); out[j].busesFrom[r] = fl;
            out[j].deadMinutes += fl * pl.sp[dep[j]].dist[pl.routes[r].stops[0]];
        }
        return out;
    }

    public static final class TspReport { public int[] hubs; public double exact, approx; public int[] exactTour; }

    /** Express loop through the busiest hubs: exact Held-Karp vs MST 2-approximation on shortest-time metric closure. */
    public static TspReport hubLoop(Planner.Plan pl, int hubs) {
        TransitData d = pl.d; int n = d.n; hubs = Math.min(hubs, n);
        int[] idx = new int[n]; long[] key = new long[n];
        for (int i = 0; i < n; i++) { idx[i] = i; key[i] = -(long) (d.weight[i] * 1000 + (n - i)); }
        Sorting.sortIdx(idx, key);
        TspReport r = new TspReport(); r.hubs = new int[hubs];
        for (int i = 0; i < hubs; i++) r.hubs[i] = idx[i];
        double[][] m = new double[hubs][hubs];
        for (int i = 0; i < hubs; i++) for (int j = 0; j < hubs; j++) m[i][j] = pl.sp[r.hubs[i]].dist[r.hubs[j]];
        Tsp.Result ex = Tsp.heldKarp(m), ap = Tsp.mstApprox(m);
        r.exact = ex.cost; r.approx = ap.cost; r.exactTour = ex.tour;
        return r;
    }
}
