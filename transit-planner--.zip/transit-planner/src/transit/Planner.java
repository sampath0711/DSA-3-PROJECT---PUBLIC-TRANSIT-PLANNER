package transit;

/**
 * Core planning pipeline (all hand-built, no java.util):
 *  1. all-pairs shortest travel times           -> Dijkstra                     (DSA-2 recap)
 *  2. candidate routes from high-demand OD pairs -> shortest paths + hashing
 *  3. choose routes under fleet+budget           -> greedy budgeted max-coverage (NP-hard, (1-1/e) approx)  [Module 5]
 *  4. split the fleet between routes             -> dynamic programming (knapsack-style)                     [Module 3]
 *  5. assign passengers to routes within seats   -> min-cost max-flow, min-cut bottlenecks                   [Module 4]
 *  6. hourly timetable + cost                    -> prefix of demand profile
 *  7. evaluate door-to-door metrics              -> Dijkstra on a (stop, route) expanded graph
 */
public final class Planner {
    private Planner() {}
    static final int NH = TransitData.NH;

    public static final class Params {
        public int fleet = 50;
        public double dailyBudget = 1e12;
        public int busCap = 50;
        public double loadFactor = 0.85;          // planning load factor (seats + standing)
        public double costPerKm = 38, costPerBusHour = 520;
        public double dwell = 1.0, layover = 10.0, egress = 2.0;
        public int minFreq = 3;                   // buses per hour per direction, every route, every hour
        public double reserve = 0.35;             // share of fleet kept back for extra frequency (DP)
        public double minGainShare = 0.02;        // a new route must serve >= 2% of still-uncovered demand
        public int maxCandidates = 70;
        public Params copy() {
            Params p = new Params(); p.fleet = fleet; p.dailyBudget = dailyBudget; p.busCap = busCap; p.loadFactor = loadFactor;
            p.costPerKm = costPerKm; p.costPerBusHour = costPerBusHour; p.dwell = dwell; p.layover = layover; p.egress = egress;
            p.minFreq = minFreq; p.reserve = reserve; p.minGainShare = minGainShare; p.maxCandidates = maxCandidates;
            return p;
        }
    }

    public static final class Route {
        public int[] stops, posOf; public double[] cum;
        public double oneWayMin, oneWayKm, roundTripMin, roundTripKm;
        public int minBuses, buses;
        public int[] freq = new int[NH], busesNeeded = new int[NH]; public double[] load = new double[NH];
        public double avgWait, dailyCost, dailyDemand, peakLoad, peakCap; public boolean bottleneck;
    }

    public static final class Plan {
        public Params p; public TransitData d; public Route[] routes; public double[][] frac;
        public double stopCoverage, directShare, reachShare, avgWait, avgTravel, fleetUtil, dailyCost, unmetPeakShare;
        public int peakFleet, effFleet, candidates, busesAssigned; public int[] hourFleet = new int[NH];
        public double[][] roadMin, roadKm; public Graph.SP[] sp;
        public final StringBuilder notes = new StringBuilder();
    }

    private static final class Asg {
        double[][] frac; double[] daily, peak; double flow, totalPeak; boolean[] bott;
    }

    private static final class Ctx {
        TransitData d; Params p; Route[] r; boolean[] direct; double[] peakDem; double maxShare;
        int[] b; Asg asg; double cost;
    }

    // ------------------------------------------------------------------------------------------
    public static Plan plan(TransitData d, Params p) {
        int n = d.n;
        Plan plan = new Plan(); plan.p = p; plan.d = d;
        Graph g = new Graph(n);
        double[][] emin = new double[n][n], ekm = new double[n][n];
        for (int i = 0; i < d.m; i++) {
            g.addUndirected(d.eu[i], d.ev[i], d.eMin[i]);
            emin[d.eu[i]][d.ev[i]] = emin[d.ev[i]][d.eu[i]] = d.eMin[i];
            ekm[d.eu[i]][d.ev[i]] = ekm[d.ev[i]][d.eu[i]] = d.eKm[i];
        }
        plan.roadMin = emin; plan.roadKm = ekm;
        Graph.SP[] sp = new Graph.SP[n];
        for (int i = 0; i < n; i++) sp[i] = g.dijkstra(i);
        plan.sp = sp;
        int k = d.k; double total = d.totalDaily();

        // --- 2. candidate routes: shortest path between the heaviest OD pairs, de-duplicated by hashing ---
        int[] idx = new int[k]; long[] key = new long[k];
        for (int i = 0; i < k; i++) { idx[i] = i; key[i] = -(long) (d.odDaily[i] * 100); }
        Sorting.sortIdx(idx, key);
        StrMap seen = new StrMap(new Rng(7));
        Route[] cand = new Route[p.maxCandidates]; int nc = 0;
        for (int t = 0; t < k && nc < p.maxCandidates; t++) {
            int o = idx[t];
            int[] path = Graph.path(sp[d.odU[o]], d.odV[o]);
            if (path == null || path.length < 2) continue;
            StringBuilder sig = new StringBuilder();
            for (int s : path) sig.append(s).append('-');
            if (seen.containsKey(sig.toString())) continue;
            seen.put(sig.toString(), 1);
            cand[nc++] = buildRoute(path, emin, ekm, n, p);
        }
        plan.candidates = nc;
        boolean[][] covers = new boolean[nc][k];
        for (int c = 0; c < nc; c++) for (int o = 0; o < k; o++) covers[c][o] = cand[c].posOf[d.odU[o]] >= 0 && cand[c].posOf[d.odV[o]] >= 0;

        // --- 3. greedy budgeted max-coverage ---
        int minAll = Integer.MAX_VALUE;
        for (int c = 0; c < nc; c++) minAll = Math.min(minAll, cand[c].minBuses);
        int budgetBuses = Math.max((int) Math.floor(p.fleet * (1 - p.reserve)), minAll);
        boolean[] covered = new boolean[k], sel = new boolean[nc];
        IntList chosen = new IntList(); int usedMin = 0; double spent = 0;
        while (true) {
            int best = -1; double bestRatio = 0;
            for (int c = 0; c < nc; c++) {
                if (sel[c] || usedMin + cand[c].minBuses > budgetBuses) continue;
                double gain = 0;
                for (int o = 0; o < k; o++) if (covers[c][o] && !covered[o]) gain += d.odDaily[o];
                double cost = baseCost(cand[c], p);
                if (spent + cost > p.dailyBudget || gain < p.minGainShare * total) continue;
                if (gain / cost > bestRatio) { bestRatio = gain / cost; best = c; }
            }
            if (best < 0) break;
            sel[best] = true; chosen.add(best); usedMin += cand[best].minBuses; spent += baseCost(cand[best], p);
            for (int o = 0; o < k; o++) if (covers[best][o]) covered[o] = true;
        }
        if (chosen.size() == 0) throw new IllegalStateException("No route fits the fleet/budget constraints");
        plan.notes.append("Candidates generated: ").append(nc).append("; greedy picked ").append(chosen.size()).append(" routes (min fleet ").append(usedMin).append(").\n");

        // --- 4+5+6. allocate buses, assign passengers, build timetable; shrink the plan until the budget holds ---
        Ctx ctx = new Ctx(); ctx.d = d; ctx.p = p; ctx.maxShare = d.maxShare();
        while (true) {
            int R = chosen.size(); ctx.r = new Route[R];
            for (int i = 0; i < R; i++) ctx.r[i] = cand[chosen.get(i)];
            ctx.direct = new boolean[k]; ctx.peakDem = new double[k];
            for (int o = 0; o < k; o++) {
                ctx.peakDem[o] = Math.ceil(d.odDaily[o] * ctx.maxShare);
                for (int i = 0; i < R; i++) if (ctx.r[i].posOf[d.odU[o]] >= 0 && ctx.r[i].posOf[d.odV[o]] >= 0) ctx.direct[o] = true;
            }
            int sumMin = 0; for (int i = 0; i < R; i++) sumMin += ctx.r[i].minBuses;
            boolean ok = false; int eff;
            for (eff = p.fleet; eff >= sumMin; eff--) { allocate(ctx, eff); if (ctx.cost <= p.dailyBudget) { ok = true; break; } }
            if (ok) { plan.effFleet = eff; break; }
            plan.notes.append("Budget infeasible with ").append(R).append(" routes - dropping the least valuable (last chosen) route.\n");
            IntList nl = new IntList();
            for (int i = 0; i < R - 1; i++) nl.add(chosen.get(i));
            chosen = nl;
            if (chosen.size() == 0) throw new IllegalStateException("Budget too small for any route");
        }
        plan.routes = ctx.r; plan.frac = ctx.asg.frac;
        plan.dailyCost = ctx.cost;
        plan.unmetPeakShare = ctx.asg.totalPeak > 0 ? Math.max(0, (ctx.asg.totalPeak - ctx.asg.flow) / ctx.asg.totalPeak) : 0;
        for (int i = 0; i < ctx.r.length; i++) { ctx.r[i].bottleneck = ctx.asg.bott[i]; plan.busesAssigned += ctx.r[i].buses; }
        evaluate(plan);
        return plan;
    }

    // ---------- route construction ----------
    private static Route buildRoute(int[] stops, double[][] emin, double[][] ekm, int n, Params p) {
        Route r = new Route(); r.stops = stops; r.cum = new double[stops.length];
        r.posOf = new int[n]; for (int i = 0; i < n; i++) r.posOf[i] = -1;
        double km = 0;
        for (int i = 0; i < stops.length; i++) {
            r.posOf[stops[i]] = i;
            if (i > 0) { r.cum[i] = r.cum[i - 1] + emin[stops[i - 1]][stops[i]] + p.dwell; km += ekm[stops[i - 1]][stops[i]]; }
        }
        r.oneWayMin = r.cum[stops.length - 1]; r.oneWayKm = km;
        r.roundTripMin = 2 * r.oneWayMin + p.layover; r.roundTripKm = 2 * km;
        r.minBuses = Math.max(2, (int) Math.ceil(r.roundTripMin * p.minFreq / 60.0 - 1e-9));
        return r;
    }
    private static double baseCost(Route r, Params p) {
        double c = 0;
        for (int h = 0; h < NH; h++) c += p.minFreq * r.roundTripKm * p.costPerKm + Math.ceil(p.minFreq * r.roundTripMin / 60.0 - 1e-9) * p.costPerBusHour;
        return c;
    }
    private static int fmax(Route r, int buses) { return (int) Math.floor(buses * 60.0 / r.roundTripMin + 1e-9); }
    private static double ivt(Route r, int u, int v) { return Math.abs(r.cum[r.posOf[u]] - r.cum[r.posOf[v]]); }

    // ---------- allocation loop: assign <-> DP until stable ----------
    private static void allocate(Ctx c, int eff) {
        int R = c.r.length; int[] b = new int[R];
        for (int i = 0; i < R; i++) b[i] = c.r[i].minBuses;
        Asg a = assign(c, b, false);
        for (int it = 0; it < 5; it++) {
            int[] nb = dpAllocate(c, a, eff);
            boolean same = true; for (int i = 0; i < R; i++) if (nb[i] != b[i]) same = false;
            b = nb; a = assign(c, b, true);
            if (same) break;
        }
        c.b = b; c.asg = a; c.cost = schedule(c, b, a);
    }

    /** Min-cost max-flow: source -> OD (peak demand) -> route (cost = ride + wait) -> sink (route seat capacity). */
    private static Asg assign(Ctx c, int[] b, boolean capped) {
        TransitData d = c.d; Params p = c.p; int R = c.r.length, k = d.k;
        IntList od = new IntList();
        for (int o = 0; o < k; o++) if (c.direct[o]) od.add(o);
        int K = od.size(), S = 0, T = K + R + 1;
        FlowNetwork f = new FlowNetwork(K + R + 2);
        int[][] eid = new int[K][R]; int[] sinkE = new int[R];
        for (int a = 0; a < K; a++) {
            int o = od.get(a); f.addEdge(S, 1 + a, (long) c.peakDem[o], 0);
            for (int r = 0; r < R; r++) {
                Route ro = c.r[r]; eid[a][r] = -1;
                if (ro.posOf[d.odU[o]] >= 0 && ro.posOf[d.odV[o]] >= 0) {
                    double cst = ivt(ro, d.odU[o], d.odV[o]) + ro.roundTripMin / (2.0 * b[r]);
                    eid[a][r] = f.addEdge(1 + a, K + 1 + r, (long) c.peakDem[o], Math.round(10 * cst));
                }
            }
        }
        for (int r = 0; r < R; r++) {
            long cap = capped ? (long) Math.floor(2.0 * fmax(c.r[r], b[r]) * p.busCap * p.loadFactor) : (long) 1e9;
            sinkE[r] = f.addEdge(K + 1 + r, T, cap, 0);
        }
        long[] res = f.minCostMaxFlow(S, T);
        Asg A = new Asg(); A.frac = new double[k][R]; A.daily = new double[R]; A.peak = new double[R]; A.bott = new boolean[R];
        for (int a = 0; a < K; a++) {
            int o = od.get(a); double served = 0;
            for (int r = 0; r < R; r++) if (eid[a][r] >= 0) served += f.flowOn(eid[a][r]);
            if (served > 0) { for (int r = 0; r < R; r++) if (eid[a][r] >= 0) A.frac[o][r] = f.flowOn(eid[a][r]) / served; }
            else {                                                     // fully blocked: fall back to cheapest route
                int br = -1; double bc = 1e18;
                for (int r = 0; r < R; r++) if (eid[a][r] >= 0) {
                    double cs = ivt(c.r[r], d.odU[o], d.odV[o]) + c.r[r].roundTripMin / (2.0 * b[r]);
                    if (cs < bc) { bc = cs; br = r; }
                }
                A.frac[o][br] = 1;
            }
            for (int r = 0; r < R; r++) { A.daily[r] += d.odDaily[o] * A.frac[o][r]; A.peak[r] += c.peakDem[o] * A.frac[o][r]; }
            A.totalPeak += c.peakDem[o];
        }
        A.flow = res[0];
        boolean[] side = f.sourceSide(S);
        for (int r = 0; r < R; r++) A.bott[r] = A.totalPeak - A.flow > 0 && side[K + 1 + r] && f.residual(sinkE[r]) == 0;
        return A;
    }

    /** DP over routes: dp[r][j] = least demand-weighted waiting using j buses on the first r routes. O(R * fleet^2). */
    private static int[] dpAllocate(Ctx c, Asg a, int eff) {
        int R = c.r.length; double INF = 1e30;
        double[][] dp = new double[R + 1][eff + 1]; int[][] ch = new int[R + 1][eff + 1];
        for (int i = 0; i <= R; i++) for (int j = 0; j <= eff; j++) dp[i][j] = INF;
        dp[0][0] = 0;
        for (int r = 0; r < R; r++) {
            Route ro = c.r[r];
            for (int j = 0; j <= eff; j++) {
                if (dp[r][j] >= INF) continue;
                for (int bb = ro.minBuses; j + bb <= eff; bb++) {
                    double cap = 2.0 * fmax(ro, bb) * c.p.busCap * c.p.loadFactor;
                    double short_ = Math.max(0, a.peak[r] - cap) / Math.max(1, a.peak[r]);
                    double cost = a.daily[r] * ro.roundTripMin / (2.0 * bb) + 60.0 * a.daily[r] * short_;
                    if (dp[r][j] + cost < dp[r + 1][j + bb]) { dp[r + 1][j + bb] = dp[r][j] + cost; ch[r + 1][j + bb] = bb; }
                }
            }
        }
        int bj = 0;
        for (int j = 0; j <= eff; j++) if (dp[R][j] < dp[R][bj]) bj = j;
        int[] b = new int[R];
        for (int r = R; r >= 1; r--) { b[r - 1] = ch[r][bj]; bj -= b[r - 1]; }
        return b;
    }

    /** Hourly frequencies, bus requirements, loads and the daily operating cost. */
    private static double schedule(Ctx c, int[] b, Asg a) {
        TransitData d = c.d; Params p = c.p; double total = 0;
        for (int r = 0; r < c.r.length; r++) {
            Route ro = c.r[r]; ro.buses = b[r]; int fm = fmax(ro, b[r]);
            double cost = 0, wl = 0, w = 0; ro.peakLoad = 0;
            for (int h = 0; h < NH; h++) {
                double load = 0;
                for (int o = 0; o < d.k; o++) load += d.odDaily[o] * a.frac[o][r] * d.hourShare[h];
                ro.load[h] = load;
                int need = (int) Math.ceil(load / 2.0 / (p.busCap * p.loadFactor) - 1e-9);
                int byRatio = (int) Math.ceil(fm * d.hourShare[h] / c.maxShare - 1e-9);
                int fr = Math.min(fm, Math.max(p.minFreq, Math.max(need, byRatio)));
                ro.freq[h] = fr;
                ro.busesNeeded[h] = (int) Math.ceil(fr * ro.roundTripMin / 60.0 - 1e-9);
                cost += fr * ro.roundTripKm * p.costPerKm + ro.busesNeeded[h] * p.costPerBusHour;
                wl += load * 30.0 / fr; w += load;
                ro.peakLoad = Math.max(ro.peakLoad, load / 2.0);
            }
            ro.peakCap = fm * p.busCap * p.loadFactor;
            ro.avgWait = w > 0 ? wl / w : 30.0 / fm;
            ro.dailyCost = cost; ro.dailyDemand = a.daily[r]; total += cost;
        }
        return total;
    }

    // ---------- evaluation on the (stop, route) expanded graph ----------
    private static void evaluate(Plan pl) {
        TransitData d = pl.d; Params p = pl.p; int n = d.n, R = pl.routes.length;
        int[] base = new int[R]; int nodes = n;
        for (int r = 0; r < R; r++) { base[r] = nodes; nodes += pl.routes[r].stops.length; }
        int[] routeOf = new int[nodes]; for (int i = 0; i < nodes; i++) routeOf[i] = -1;
        Graph tg = new Graph(nodes); boolean[] served = new boolean[n];
        for (int r = 0; r < R; r++) {
            Route ro = pl.routes[r];
            for (int i = 0; i < ro.stops.length; i++) {
                int node = base[r] + i; routeOf[node] = r; served[ro.stops[i]] = true;
                tg.addEdge(ro.stops[i], node, ro.avgWait);        // board: wait half a headway
                tg.addEdge(node, ro.stops[i], p.egress);          // alight / walk / transfer
                if (i + 1 < ro.stops.length) { double seg = ro.cum[i + 1] - ro.cum[i]; tg.addEdge(node, node + 1, seg); tg.addEdge(node + 1, node, seg); }
            }
        }
        int sc = 0; for (int i = 0; i < n; i++) if (served[i]) sc++;
        pl.stopCoverage = (double) sc / n;
        Graph.SP[] cache = new Graph.SP[n];
        double tot = 0, dir = 0, reach = 0, tt = 0, ww = 0;
        for (int o = 0; o < d.k; o++) {
            int u = d.odU[o], v = d.odV[o]; double q = d.odDaily[o]; tot += q;
            boolean direct = false;
            for (int r = 0; r < R; r++) if (pl.routes[r].posOf[u] >= 0 && pl.routes[r].posOf[v] >= 0) direct = true;
            if (direct) dir += q;
            if (cache[u] == null) cache[u] = tg.dijkstra(u);
            Graph.SP s = cache[u];
            if (s.dist[v] >= Graph.INF) continue;
            reach += q; tt += q * s.dist[v];
            double w = 0;
            for (int x = v; x != u; x = s.parent[x]) { int pr = s.parent[x]; if (pr < n && x >= n) w += pl.routes[routeOf[x]].avgWait; }
            ww += q * w;
        }
        pl.directShare = dir / tot; pl.reachShare = reach / tot;
        pl.avgTravel = reach > 0 ? tt / reach : 0; pl.avgWait = reach > 0 ? ww / reach : 0;
        int used = 0;
        for (int h = 0; h < NH; h++) {
            int s = 0; for (int r = 0; r < R; r++) s += pl.routes[r].busesNeeded[h];
            pl.hourFleet[h] = s; used += s; pl.peakFleet = Math.max(pl.peakFleet, s);
        }
        pl.fleetUtil = (double) used / (p.fleet * (double) NH);
    }
}
