package transit;

/** Cleaned, validated transit data (output of DataCleaner). */
public final class TransitData {
    public static final int H0 = 5, NH = 18;          // service hours 05:00 - 22:59
    public int n; public String[] name; public double[] x, y, weight;
    public int m; public int[] eu, ev; public double[] eMin, eKm;       // undirected road links
    public int k; public int[] odU, odV; public double[] odDaily;       // undirected OD pairs (u < v)
    public double[] hourShare = new double[NH];                          // sums to 1
    public final StringBuilder log = new StringBuilder();
    public int stopsRaw, stopsKept, travelRaw, travelKept, demandRaw, demandKept, fuzzyFixed, dropped, merged;
    public boolean connected;

    public double totalDaily() { double t = 0; for (int i = 0; i < k; i++) t += odDaily[i]; return t; }
    public double maxShare() { double m = 0; for (double s : hourShare) if (s > m) m = s; return m; }
}
