package transit;

/** Module 5: TSP is NP-hard - exact Held-Karp O(n^2 2^n) vs the MST-based 2-approximation. */
public final class Tsp {
    private Tsp() {}
    public static final class Result { public double cost; public int[] tour; }

    public static Result heldKarp(double[][] d) {
        int n = d.length; Result r = new Result();
        if (n == 1) { r.cost = 0; r.tour = new int[]{0}; return r; }
        double INF = 1e18; int full = 1 << n;
        double[][] dp = new double[full][n]; int[][] par = new int[full][n];
        for (int i = 0; i < full; i++) for (int j = 0; j < n; j++) { dp[i][j] = INF; par[i][j] = -1; }
        dp[1][0] = 0;
        for (int mask = 1; mask < full; mask += 2)
            for (int j = 0; j < n; j++) {
                if (dp[mask][j] >= INF) continue;
                for (int k = 1; k < n; k++) {
                    if ((mask & (1 << k)) != 0) continue;
                    int nm = mask | (1 << k); double c = dp[mask][j] + d[j][k];
                    if (c < dp[nm][k]) { dp[nm][k] = c; par[nm][k] = j; }
                }
            }
        double best = INF; int last = -1;
        for (int j = 1; j < n; j++) { double c = dp[full - 1][j] + d[j][0]; if (c < best) { best = c; last = j; } }
        r.cost = best; r.tour = new int[n];
        int mask = full - 1, cur = last;
        for (int i = n - 1; i >= 1; i--) { r.tour[i] = cur; int p = par[mask][cur]; mask ^= (1 << cur); cur = p; }
        r.tour[0] = 0;
        return r;
    }

    /** MST (Prim) + preorder walk: tour cost <= 2 * OPT when d satisfies the triangle inequality. */
    public static Result mstApprox(double[][] d) {
        int n = d.length; Result r = new Result();
        double[] key = new double[n]; int[] par = new int[n]; boolean[] in = new boolean[n];
        for (int i = 0; i < n; i++) { key[i] = 1e18; par[i] = -1; }
        key[0] = 0;
        for (int it = 0; it < n; it++) {
            int u = -1;
            for (int i = 0; i < n; i++) if (!in[i] && (u == -1 || key[i] < key[u])) u = i;
            in[u] = true;
            for (int v = 0; v < n; v++) if (!in[v] && d[u][v] < key[v]) { key[v] = d[u][v]; par[v] = u; }
        }
        int[] child = new int[n], sib = new int[n];
        for (int i = 0; i < n; i++) { child[i] = -1; sib[i] = -1; }
        for (int v = n - 1; v >= 1; v--) { sib[v] = child[par[v]]; child[par[v]] = v; }
        r.tour = new int[n]; int cnt = 0;
        int[] stack = new int[n + 1]; int sp = 0; stack[sp++] = 0;
        while (sp > 0) {
            int u = stack[--sp]; r.tour[cnt++] = u;
            for (int c = child[u]; c != -1; c = sib[c]) stack[sp++] = c;
        }
        for (int i = 0; i < n; i++) r.cost += d[r.tour[i]][r.tour[(i + 1) % n]];
        return r;
    }

    /** Brute force (n <= 9) for verification. */
    public static double brute(double[][] d) {
        int n = d.length; int[] perm = new int[n]; for (int i = 0; i < n; i++) perm[i] = i;
        return permute(d, perm, 1);
    }
    private static double permute(double[][] d, int[] p, int k) {
        int n = p.length;
        if (k == n) { double c = 0; for (int i = 0; i < n; i++) c += d[p[i]][p[(i + 1) % n]]; return c; }
        double best = 1e18;
        for (int i = k; i < n; i++) {
            int t = p[k]; p[k] = p[i]; p[i] = t;
            best = Math.min(best, permute(d, p, k + 1));
            t = p[k]; p[k] = p[i]; p[i] = t;
        }
        return best;
    }
}
