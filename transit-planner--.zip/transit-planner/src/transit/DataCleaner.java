package transit;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Data collection + cleaning pipeline (the "data preprocessing" step of the abstract).
 * Normalisation -> exact de-duplication (hash table) -> fuzzy repair of typos (Damerau-Levenshtein)
 * -> validation (ranges, NaN, self-loops) -> canonicalisation of OD pairs.
 */
public final class DataCleaner {
    private DataCleaner() {}
    private static int logLines = 0;

    static String[] readLines(String path) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(path));
        String[] a = new String[64]; int c = 0; String line;
        while ((line = br.readLine()) != null) {
            if (line.trim().isEmpty()) continue;
            if (c == a.length) { String[] b = new String[c * 2]; System.arraycopy(a, 0, b, 0, c); a = b; }
            a[c++] = line;
        }
        br.close();
        String[] r = new String[Math.max(0, c - 1)];             // drop header
        for (int i = 1; i < c; i++) r[i - 1] = a[i];
        return r;
    }
    static String[] split(String line) {
        int cnt = 1;
        for (int i = 0; i < line.length(); i++) if (line.charAt(i) == ',') cnt++;
        String[] f = new String[cnt]; int pos = 0;
        for (int i = 0; i < cnt; i++) {
            int e = line.indexOf(',', pos); if (e < 0) e = line.length();
            f[i] = line.substring(pos, e).trim(); pos = e + 1;
        }
        return f;
    }
    static String squeeze(String s) {
        StringBuilder b = new StringBuilder(); boolean sp = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\t') { sp = b.length() > 0; continue; }
            if (sp) b.append(' ');
            sp = false; b.append(c);
        }
        return b.toString();
    }
    static String norm(String s) { return squeeze(s).toLowerCase(); }
    static double num(String s) { try { return Double.parseDouble(s); } catch (NumberFormatException e) { return Double.NaN; } }
    static int thr(int len) { return len <= 4 ? 0 : (len <= 9 ? 1 : 2); }
    private static void log(TransitData d, String msg) { if (logLines++ < 80) d.log.append(msg).append('\n'); }

    /** Exact lookup, else unique nearest neighbour within the edit-distance threshold, else -1. */
    static int resolve(TransitData d, String raw, String[] keys, int cnt, StrMap map) {
        String k = norm(raw);
        int id = map.get(k, -1);
        if (id >= 0) return id;
        int best = Integer.MAX_VALUE, second = Integer.MAX_VALUE, bi = -1;
        for (int i = 0; i < cnt; i++) {
            int dd = EditDistance.damerau(k, keys[i]);
            if (dd < best) { second = best; best = dd; bi = i; } else if (dd < second) second = dd;
        }
        if (bi >= 0 && best <= thr(k.length()) && second > best) {
            d.fuzzyFixed++; map.put(k, bi);
            log(d, "  fuzzy-fix  '" + squeeze(raw) + "' -> '" + d.name[bi] + "' (edit distance " + best + ")");
            return bi;
        }
        return -1;
    }

    public static TransitData load(String dir) throws IOException {
        TransitData d = new TransitData(); logLines = 0;
        Rng rng = new Rng(2026);
        // ---------------- stops ----------------
        String[] rows = readLines(dir + "/stops_raw.csv"); d.stopsRaw = rows.length;
        String[] nm = new String[rows.length], keys = new String[rows.length];
        double[] x = new double[rows.length], y = new double[rows.length], wt = new double[rows.length];
        StrMap map = new StrMap(rng); int cnt = 0;
        for (String row : rows) {
            String[] f = split(row);
            double px = f.length > 1 ? num(f[1]) : Double.NaN, py = f.length > 2 ? num(f[2]) : Double.NaN, pw = f.length > 3 ? num(f[3]) : Double.NaN;
            String name = f.length > 0 ? squeeze(f[0]) : "";
            if (name.isEmpty() || Double.isNaN(px) || Double.isNaN(py) || Double.isNaN(pw)) {
                d.dropped++; log(d, "  dropped stop row (missing/invalid field): '" + row + "'"); continue;
            }
            String key = norm(name);
            if (map.containsKey(key)) { d.merged++; log(d, "  duplicate  '" + name + "' (same as existing stop)"); continue; }
            int near = -1;
            for (int i = 0; i < cnt && near < 0; i++) if (EditDistance.damerau(key, keys[i]) <= thr(key.length())) near = i;
            if (near >= 0) { d.merged++; map.put(key, near); log(d, "  merged     '" + name + "' into '" + nm[near] + "' (near-duplicate)"); continue; }
            nm[cnt] = name; keys[cnt] = key; x[cnt] = px; y[cnt] = py; wt[cnt] = pw; map.put(key, cnt); cnt++;
        }
        d.n = cnt; d.stopsKept = cnt;
        d.name = new String[cnt]; d.x = new double[cnt]; d.y = new double[cnt]; d.weight = new double[cnt];
        for (int i = 0; i < cnt; i++) { d.name[i] = nm[i]; d.x[i] = x[i]; d.y[i] = y[i]; d.weight[i] = wt[i]; }

        // ---------------- travel times ----------------
        rows = readLines(dir + "/travel_raw.csv"); d.travelRaw = rows.length;
        d.eu = new int[rows.length]; d.ev = new int[rows.length]; d.eMin = new double[rows.length]; d.eKm = new double[rows.length];
        StrMap pairs = new StrMap(rng);
        for (String row : rows) {
            String[] f = split(row);
            if (f.length < 4) { d.dropped++; continue; }
            int u = resolve(d, f[0], keys, cnt, map), v = resolve(d, f[1], keys, cnt, map);
            double mi = num(f[2]), km = num(f[3]);
            if (u < 0 || v < 0) { d.dropped++; log(d, "  dropped link (unknown stop): '" + row + "'"); continue; }
            if (u == v) { d.dropped++; log(d, "  dropped link (self loop): '" + row + "'"); continue; }
            if (!(mi > 0 && mi <= 90) || !(km > 0 && km <= 60)) { d.dropped++; log(d, "  dropped link (invalid time/km): '" + row + "'"); continue; }
            String pk = Math.min(u, v) + "-" + Math.max(u, v);
            if (pairs.containsKey(pk)) { d.merged++; log(d, "  duplicate link " + d.name[u] + " - " + d.name[v] + " ignored"); continue; }
            pairs.put(pk, d.m);
            d.eu[d.m] = u; d.ev[d.m] = v; d.eMin[d.m] = mi; d.eKm[d.m] = km; d.m++;
        }
        d.travelKept = d.m;
        Graph g = new Graph(d.n);
        for (int i = 0; i < d.m; i++) g.addUndirected(d.eu[i], d.ev[i], d.eMin[i]);
        d.connected = g.connected();

        // ---------------- demand ----------------
        rows = readLines(dir + "/demand_raw.csv"); d.demandRaw = rows.length;
        d.odU = new int[rows.length]; d.odV = new int[rows.length]; d.odDaily = new double[rows.length];
        StrMap od = new StrMap(rng);
        for (String row : rows) {
            String[] f = split(row);
            if (f.length < 3) { d.dropped++; continue; }
            int u = resolve(d, f[0], keys, cnt, map), v = resolve(d, f[1], keys, cnt, map); double q = num(f[2]);
            if (u < 0 || v < 0) { d.dropped++; log(d, "  dropped demand (unknown stop): '" + row + "'"); continue; }
            if (u == v) { d.dropped++; log(d, "  dropped demand (self loop): '" + row + "'"); continue; }
            if (!(q > 0 && q < 200000)) { d.dropped++; log(d, "  dropped demand (invalid count): '" + row + "'"); continue; }
            String pk = Math.min(u, v) + "-" + Math.max(u, v);
            int at = od.get(pk, -1);
            if (at < 0) { od.put(pk, d.k); d.odU[d.k] = Math.min(u, v); d.odV[d.k] = Math.max(u, v); d.odDaily[d.k] = q; d.k++; }
            else d.odDaily[at] += q;                         // merge A->B and B->A into one undirected pair
            d.demandKept++;
        }

        // ---------------- hourly profile ----------------
        rows = readLines(dir + "/hourly_profile.csv"); double tot = 0;
        for (String row : rows) {
            String[] f = split(row); if (f.length < 2) continue;
            int h = (int) num(f[0]); double s = num(f[1]);
            if (h >= TransitData.H0 && h < TransitData.H0 + TransitData.NH && s > 0) { d.hourShare[h - TransitData.H0] = s; }
        }
        for (double s : d.hourShare) tot += s;
        for (int i = 0; i < TransitData.NH; i++) d.hourShare[i] = tot > 0 ? d.hourShare[i] / tot : 1.0 / TransitData.NH;
        return d;
    }
}
