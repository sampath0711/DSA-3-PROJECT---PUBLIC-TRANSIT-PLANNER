package transit;

/** Module 2: exact pattern matching. All return start indices of matches. */
public final class StringAlgos {
    private StringAlgos() {}
    public static int rkCollisions = 0;   // hash hits that turned out to be false positives

    // ---- Knuth-Morris-Pratt ----
    public static int[] failure(String p) {
        int m = p.length(); int[] f = new int[m]; int k = 0;
        for (int i = 1; i < m; i++) {
            while (k > 0 && p.charAt(i) != p.charAt(k)) k = f[k - 1];
            if (p.charAt(i) == p.charAt(k)) k++;
            f[i] = k;
        }
        return f;
    }
    public static IntList kmp(String t, String p) {
        IntList res = new IntList(); int m = p.length();
        if (m == 0) return res;
        int[] f = failure(p); int k = 0;
        for (int i = 0; i < t.length(); i++) {
            while (k > 0 && t.charAt(i) != p.charAt(k)) k = f[k - 1];
            if (t.charAt(i) == p.charAt(k)) k++;
            if (k == m) { res.add(i - m + 1); k = f[k - 1]; }
        }
        return res;
    }

    // ---- Z-function ----
    public static int[] z(String s) {
        int n = s.length(); int[] z = new int[n]; int l = 0, r = 0;
        for (int i = 1; i < n; i++) {
            if (i < r) z[i] = Math.min(r - i, z[i - l]);
            while (i + z[i] < n && s.charAt(z[i]) == s.charAt(i + z[i])) z[i]++;
            if (i + z[i] > r) { l = i; r = i + z[i]; }
        }
        if (n > 0) z[0] = n;
        return z;
    }
    public static IntList zSearch(String t, String p) {
        IntList res = new IntList(); int m = p.length();
        if (m == 0) return res;
        int[] z = z(p + '\u0001' + t);
        for (int i = m + 1; i < z.length; i++) if (z[i] >= m) res.add(i - m - 1);
        return res;
    }

    // ---- Rabin-Karp with random prime modulus and random base (Las Vegas: hits are verified) ----
    public static IntList rabinKarp(String t, String p, Rng r) {
        IntList res = new IntList(); int n = t.length(), m = p.length();
        if (m == 0 || m > n) return res;
        long mod = NumberTheory.randomPrime(31, r), B = 256 + r.nextInt(1 << 20);
        long hp = 0, ht = 0, pw = 1;
        for (int i = 0; i < m; i++) {
            hp = (hp * B + p.charAt(i)) % mod;
            ht = (ht * B + t.charAt(i)) % mod;
            if (i < m - 1) pw = pw * B % mod;
        }
        for (int i = 0; ; i++) {
            if (hp == ht) { if (t.regionMatches(i, p, 0, m)) res.add(i); else rkCollisions++; }
            if (i + m >= n) break;
            ht = ((ht - t.charAt(i) * pw) % mod + mod) % mod;
            ht = (ht * B + t.charAt(i + m)) % mod;
        }
        return res;
    }

    /** Naive O(nm) baseline, used by the self-tests. */
    public static IntList naive(String t, String p) {
        IntList res = new IntList(); int m = p.length();
        if (m == 0) return res;
        for (int i = 0; i + m <= t.length(); i++) if (t.regionMatches(i, p, 0, m)) res.add(i);
        return res;
    }
}
