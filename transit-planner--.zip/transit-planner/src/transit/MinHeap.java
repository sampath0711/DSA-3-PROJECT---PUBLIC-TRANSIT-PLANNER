package transit;

/** Binary min-heap of (priority, item) pairs; lazy deletion is handled by the caller (Dijkstra). */
public final class MinHeap {
    private double[] pr = new double[16]; private int[] it = new int[16]; private int n;
    public boolean isEmpty() { return n == 0; }
    public double peekPrio() { return pr[0]; }
    public void push(double p, int item) {
        if (n == pr.length) {
            double[] a = new double[n * 2]; int[] b = new int[n * 2];
            System.arraycopy(pr, 0, a, 0, n); System.arraycopy(it, 0, b, 0, n); pr = a; it = b;
        }
        int i = n++;
        while (i > 0) {
            int par = (i - 1) >> 1;
            if (pr[par] <= p) break;
            pr[i] = pr[par]; it[i] = it[par]; i = par;
        }
        pr[i] = p; it[i] = item;
    }
    public int pop() {
        int top = it[0]; n--;
        if (n > 0) {
            double p = pr[n]; int item = it[n]; int i = 0;
            while (true) {
                int c = 2 * i + 1;
                if (c >= n) break;
                if (c + 1 < n && pr[c + 1] < pr[c]) c++;
                if (pr[c] >= p) break;
                pr[i] = pr[c]; it[i] = it[c]; i = c;
            }
            pr[i] = p; it[i] = item;
        }
        return top;
    }
}
