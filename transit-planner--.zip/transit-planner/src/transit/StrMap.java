package transit;

/** String -> int hash table: open addressing + randomised polynomial hash (random prime modulus and base). */
public final class StrMap {
    private String[] keys = new String[16];
    private int[] vals = new int[16];
    private int size;
    private final long p, base;

    public StrMap(Rng r) {
        p = NumberTheory.randomPrime(31, r);
        base = 300 + r.nextInt(1 << 20);
    }
    private int slot(String k, int cap) {
        long h = 0;
        for (int i = 0; i < k.length(); i++) h = (h * base + k.charAt(i)) % p;
        return (int) (h & (cap - 1));
    }
    public int get(String k, int def) {
        int cap = keys.length, i = slot(k, cap);
        while (keys[i] != null) { if (keys[i].equals(k)) return vals[i]; i = (i + 1) & (cap - 1); }
        return def;
    }
    public boolean containsKey(String k) { return get(k, Integer.MIN_VALUE) != Integer.MIN_VALUE; }
    public void put(String k, int v) {
        if ((size + 1) * 2 > keys.length) grow();
        int cap = keys.length, i = slot(k, cap);
        while (keys[i] != null) { if (keys[i].equals(k)) { vals[i] = v; return; } i = (i + 1) & (cap - 1); }
        keys[i] = k; vals[i] = v; size++;
    }
    private void grow() {
        String[] ok = keys; int[] ov = vals;
        keys = new String[ok.length * 2]; vals = new int[ok.length * 2]; size = 0;
        for (int i = 0; i < ok.length; i++) if (ok[i] != null) put(ok[i], ov[i]);
    }
    public int size() { return size; }
}
