@echo off
if not exist out mkdir out
javac -d out src\transit\*.java && java -cp out transit.Main %*
