#!/bin/sh
# Compile everything and start the web portal at http://localhost:8080
mkdir -p out && javac -d out src/transit/*.java && java -cp out transit.Server
