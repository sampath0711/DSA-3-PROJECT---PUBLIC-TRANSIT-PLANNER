#!/bin/sh
[ -d out ] || ./build.sh
java -cp out transit.Main "$@"
