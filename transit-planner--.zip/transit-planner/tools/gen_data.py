"""Generates the raw (intentionally dirty) CSV files in ../data.
The data is SYNTHETIC but Hyderabad-flavoured: stop names are real localities,
coordinates are approximate km offsets, travel times and demand come from a
simple gravity model. Run once; the Java project only reads the CSV files."""
import math, random, os
random.seed(42)
OUT = os.path.join(os.path.dirname(__file__), "..", "data")

# name, x_km, y_km, weight (1-10 = size of trip generator)
STOPS = [
 ("Secunderabad",12,16,10),("Paradise",11,14.5,6),("Begumpet",8.5,13.5,6),("Ameerpet",6.5,12.5,9),
 ("SR Nagar",5.5,13,5),("Punjagutta",7.5,11,6),("Khairatabad",8.5,10.5,5),("Lakdikapul",9,10,4),
 ("Nampally",10,9.5,7),("Abids",11,10,7),("Koti",12.5,9,9),("MGBS",12,8,8),("Charminar",12,6.5,7),
 ("Dilsukhnagar",16,7.5,8),("LB Nagar",18.5,6.5,8),("Mehdipatnam",6.5,7.5,8),("Tolichowki",4.5,8,5),
 ("Gachibowli",1.5,10.5,9),("Madhapur",3.5,11.5,8),("HITEC City",2.5,12.5,10),("Kondapur",1,13,6),
 ("Miyapur",-2,15,7),("Kukatpally",1,16,8),("JNTU",3,15,6),("Jubilee Hills",5,11,5),
 ("Banjara Hills",6.5,9.5,5),("Malakpet",13.5,8.5,4),("Uppal",21,11,7),("Tarnaka",13.5,13,5),("Aziz Nagar",-2,5,5),
]
EDGES = [("Secunderabad","Paradise"),("Secunderabad","Tarnaka"),("Secunderabad","Begumpet"),("Paradise","Begumpet"),
 ("Begumpet","Ameerpet"),("Begumpet","SR Nagar"),("Ameerpet","SR Nagar"),("Ameerpet","Punjagutta"),
 ("Ameerpet","Jubilee Hills"),("SR Nagar","Kukatpally"),("SR Nagar","JNTU"),("Punjagutta","Khairatabad"),
 ("Punjagutta","Banjara Hills"),("Khairatabad","Lakdikapul"),("Lakdikapul","Nampally"),("Lakdikapul","Banjara Hills"),
 ("Nampally","Abids"),("Nampally","Mehdipatnam"),("Abids","Koti"),("Koti","MGBS"),("Koti","Malakpet"),
 ("MGBS","Charminar"),("Charminar","Malakpet"),("Malakpet","Dilsukhnagar"),("Dilsukhnagar","LB Nagar"),
 ("LB Nagar","Uppal"),("Uppal","Tarnaka"),("Mehdipatnam","Tolichowki"),("Mehdipatnam","Banjara Hills"),
 ("Mehdipatnam","Charminar"),("Mehdipatnam","Aziz Nagar"),("Tolichowki","Gachibowli"),("Tolichowki","Jubilee Hills"),
 ("Gachibowli","Madhapur"),("Gachibowli","Aziz Nagar"),("Madhapur","HITEC City"),("Madhapur","Jubilee Hills"),
 ("Madhapur","JNTU"),("HITEC City","Kondapur"),("Kondapur","Miyapur"),("Miyapur","Kukatpally"),("Kukatpally","JNTU"),
 ("Banjara Hills","Jubilee Hills"),("Paradise","Abids"),("Tarnaka","Nampally")]
P = {s[0]: s for s in STOPS}
def dist(a, b):
    return math.hypot(P[a][1]-P[b][1], P[a][2]-P[b][2]) * 1.3

def w(path, rows, header):
    with open(os.path.join(OUT, path), "w") as f:
        f.write(header + "\n")
        for r in rows: f.write(",".join(str(c) for c in r) + "\n")

# ---------- stops (clean rows first, dirty rows appended) ----------
rows = [(n, x, y, wt) for n, x, y, wt in STOPS]
rows += [("  ameerpet", 6.5, 12.5, 9), ("Gachibwli", 1.6, 10.4, 9), ("Kukatpalli", 1, 16, 8),
         ("Madhapur", "", "", 8), ("HITEC CITY", 2.5, 12.5, 10), ("Mehdipatnam", "abc", 7.5, 8),
         ("", 5, 5, 1), ("Secunderabad ", 12, 16, 10)]
w("stops_raw.csv", rows, "name,x_km,y_km,weight")

# ---------- travel times ----------
tr = []
for a, b in EDGES:
    km = dist(a, b); sp = random.uniform(16, 26)
    tr.append((a, b, round(max(2.0, km / sp * 60), 1), round(km, 1)))
dirty = [("Ameerpet", "Begumpet", 6.0, 3.0),          # reversed duplicate
         ("Hyd Airport", "Uppal", 40, 30),              # unknown stop
         ("Secundrabad", "Tarnaka", tr[1][2], tr[1][3]),# typo, duplicate of real edge
         ("Koti", "Abids", -5, 1.5),                    # negative time
         ("Koti", "Koti", 3, 0.1),                      # self loop
         ("Charminar", "MGBS", 999, 2.0),               # outlier
         ("ameerpet", "punjagutta", "n/a", 2.0)]        # non numeric
rows = tr + dirty; random.shuffle(rows)
w("travel_raw.csv", rows, "from,to,minutes,km")

# ---------- demand (directed rows; Java merges into undirected pairs) ----------
K = 60; rows = []
names = [s[0] for s in STOPS]
cand = []
for i in range(len(names)):
    for j in range(i+1, len(names)):
        a, b = names[i], names[j]
        cand.append((K * P[a][3] * P[b][3] / (dist(a, b) + 4.0), a, b))
cand.sort(reverse=True)
pairs = 110
for d, a, b in cand[:pairs]:
    x = round(d * random.uniform(0.45, 0.55)); rows.append((a, b, x)); rows.append((b, a, round(d) - x))
rows += [("Ameerpt", "HITEC City", 180), ("Koti", "Uppal", "N/A"), ("Madhapur", "Gachibowli", -60),
         ("Nowhere", "Koti", 100), ("Uppal", "Uppal", 140), ("hitec city", "ameerpet", 300)]
random.shuffle(rows)
w("demand_raw.csv", rows, "origin,destination,daily_passengers")
print("od pairs:", pairs, "total daily:", sum(r[2] for r in rows if isinstance(r[2], int)))

# ---------- hourly profile (5:00 - 22:59) ----------
prof = [1,2.5,6,10,11,7,5,4.5,4.5,4.5,5,6.5,9,11,8,5,3,1.5]
w("hourly_profile.csv", [(5+i, v) for i, v in enumerate(prof)], "hour,weight")
