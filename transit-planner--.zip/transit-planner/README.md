# Public Transit Planner  (DSA-3, 25CS2103E, A.Y. 2026-27)

Team 12, Section 11 - M S S M V Sampath (2520090005), M Susheel Rao (2520080064), S Kaushik (2520090113)
Guide: Mrs. Ch. Anitha, Asst. Professor, CS&IT

A data-driven planner that cleans transit data, designs bus routes and hourly timetables under a **fixed fleet and
daily budget**, and evaluates them with coverage, waiting time, travel time, fleet utilisation and cost.
Every algorithm is hand-built: **no `java.util` anywhere** (rule carried over from DSA-1/DSA-2).
Only `java.io` (read CSV, write report) and `java.lang.Thread` (parallel scan) are used.

## Run the website (Passenger + Admin portals) - plain javac / java
```
javac -d out src/transit/*.java
java -cp out transit.Server          # or ./serve.sh   (serve.bat on Windows)
```
Then open **http://localhost:8080**. Run it from the project folder (it reads `data/` and `web/`).
Options: `java -Dport=9000 -Dpin=4321 -cp out transit.Server`.

* **Passenger portal** - plan a trip (From / To / when), live departure board for any stop, and a page per bus line (Java: `Journey`).
* **Admin portal** - sign in with the PIN (default `1234`), set fleet size and daily budget, read a plain-English summary with
  colour-coded results, ask for a recommended fleet size, view the timetable and compare saved plans. Changes are a *draft* until **Publish to passengers**.
* The browser page (`web/index.html`) only draws what the Java server returns. All planning is in `Planner`, `Journey`, `Json`, `Server`.
* The server uses only the JDK's built-in `com.sun.net.httpserver` (no frameworks, no `java.util`).
* The PIN is checked on the server, but this is still a demo: HTTP only, one shared admin token, nothing saved to disk.
* `offline-demos/` holds the earlier stand-alone HTML versions (no Java needed, planner re-written in JavaScript).

## Run it (command line)
Needs JDK 17+ (tested on 21).
```
./build.sh                       # or build.bat on Windows: compiles into out/
./run.sh demo                    # full pipeline + writes output/report.html  (open it in a browser)
./run.sh selftest                # 7,470 randomised checks of every algorithm vs a slow baseline
./run.sh search "from ameerpet to hitec city"   # Aho-Corasick finds the stops in a sentence
./run.sh search nagar            # suffix-array substring lookup
./run.sh fuzzy Gachibwli         # typo repair with edit distances
./run.sh route Ameerpet Koti     # fastest road path (Dijkstra)
./run.sh plan 50                 # plan with a 50-bus fleet  (second arg = daily budget in Rs)
./run.sh plan 60 450000
./run.sh tsp                     # exact vs approximate express loop through the 12 busiest hubs
```

## Pipeline  (abstract -> code)
| Abstract says | What happens | Where |
|---|---|---|
| collect + clean stop, demand, travel-time data | normalise, de-duplicate (hash table), repair typos (Damerau-Levenshtein), validate ranges, merge A->B/B->A demand | `DataCleaner` |
| graph-based routing | Dijkstra on the road network; candidate routes = shortest paths between the heaviest OD pairs | `Graph`, `Planner` |
| maximise coverage within fixed fleet + budget | route choice = budgeted max-coverage (NP-hard) -> greedy, (1-1/e) approximation | `Planner.plan` |
| minimise passenger travel time | fleet split between routes by dynamic programming; passengers assigned by min-cost max-flow within seat capacity | `Planner.dpAllocate / assign` |
| timetables from demand + availability | per route per hour: frequency from load, capped by the buses allocated; departures evenly spaced | `Planner.schedule`, `ReportWriter.timetable` |
| metrics: coverage, wait, travel time, utilisation, cost | door-to-door times via Dijkstra on a (stop, route) expanded graph; cost = km + bus-hours | `Planner.evaluate` |
| interactive reports, compare scenarios | `output/report.html`: tabs per scenario, SVG map, bar charts, timetable heat-table | `ReportWriter` |

## Syllabus coverage
| Module | Topics used |
|---|---|
| 1 TextHack-style engine | command-line query engine working from day one; no `java.util` |
| 2 String algorithms | KMP, Z, Rabin-Karp (random prime), Aho-Corasick, suffix array + Kasai LCP (`StringAlgos`, `AhoCorasick`, `SuffixArray`) |
| 3 Advanced DP | Levenshtein / Damerau / weighted edit distance, Needleman-Wunsch + Smith-Waterman on route stop-sequences, allocation DP, Held-Karp bitmask DP |
| 4 Network flow | Edmonds-Karp, Dinic, min-cut verification, min-cost max-flow (passenger assignment, bus-to-depot assignment) (`FlowNetwork`, `Analysis`) |
| 5 NP-completeness + approximation | max-coverage greedy ratio, MST 2-approximation vs exact TSP |
| 6 Randomised + parallel | Miller-Rabin, randomised quicksort, universal hashing (`StrMap`), Monte Carlo wait simulation, reservoir sampling, parallel prefix-sum / reduce + Blelloch scan (`Simulator`, `ParallelScan`) |

## Data
`data/*.csv` is **synthetic but Hyderabad-flavoured**: real locality names, approximate coordinates, times and demand from a gravity
model (`tools/gen_data.py`, seed fixed). It deliberately contains dirty rows (typos, duplicates, negatives, unknown stops) so the cleaner has work to do.
Replace the three raw CSVs with real GTFS/ridership exports (same columns) to plan a real city.

## Simplifications to state in the viva
* Passengers who need a transfer are counted in travel-time/wait metrics but not in the seat-capacity flow (only direct trips load routes).
* Each route is a two-way line with a fixed round-trip time; frequency is the same in both directions.
* Cost model: Rs 38 per bus-km + Rs 520 per bus-hour (editable in `Planner.Params`).

## Presenting it
See `VIVA_GUIDE.md` for a demo script, algorithm-to-question table and honest answers to hard questions.
