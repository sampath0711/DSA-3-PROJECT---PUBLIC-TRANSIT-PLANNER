#!/bin/sh
mkdir -p out && javac -d out src/transit/*.java && echo "built into out/"
